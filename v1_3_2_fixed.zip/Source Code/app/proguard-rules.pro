# ShadowStudio ProGuard Rules
# Add project specific ProGuard rules here

-keepattributes *Annotation*
-keepattributes Signature
-keepattributes Exceptions

# Keep data classes
-keep class com.Studio.Shadows.data.model.** { *; }

# Keep Retrofit models
-keep class retrofit2.** { *; }
-keepclassmembers class * {
    @retrofit2.http.* <methods>;
}

# Keep Room entities
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *

# Keep Hilt
-keep class dagger.hilt.** { *; }
