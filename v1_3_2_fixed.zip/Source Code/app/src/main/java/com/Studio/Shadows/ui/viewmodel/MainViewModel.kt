package com.Studio.Shadows.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.Studio.Shadows.security.SecurityManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val securityManager: SecurityManager
) : ViewModel() {

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated

    /**
     * Called once from onCreate (behind the splash screen).
     *
     * App lock is only required when:
     *   - At least one entry method (biometric OR pin) is enabled, AND
     *   - The global lock switch is ON.
     *
     * If either condition is false the app auto-unlocks so users with no
     * security configured (or with entry methods off) are never blocked.
     */
    suspend fun checkAuthentication() {
        val config = securityManager.getSecurityConfig().firstOrNull()
        val hasAuthMethod = config?.let { it.biometricEnabled || it.pinEnabled } ?: false
        val globalLockOn = config?.globalLockEnabled ?: false
        _isAuthenticated.value = !(hasAuthMethod && globalLockOn)
    }

    fun authenticate() { _isAuthenticated.value = true }

    fun lockApp() { _isAuthenticated.value = false }
}
