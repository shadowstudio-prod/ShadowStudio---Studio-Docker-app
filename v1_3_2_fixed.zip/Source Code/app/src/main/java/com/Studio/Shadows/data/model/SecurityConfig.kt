package com.Studio.Shadows.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Security configuration for ShadowStudio.
 *
 * Lock model:
 *   biometricEnabled / pinEnabled  — entry method toggles (dormant unless a lock is active)
 *   securitySettingsLockEnabled    — gates Security Settings screen (requires an entry method)
 *   globalLockEnabled              — gates entire app on launch/resume (requires an entry method)
 *
 * Neither lock does anything unless at least one entry method is enabled.
 */
@Entity(tableName = "security_config")
data class SecurityConfig(
    @PrimaryKey
    val id: Int = 1,

    // ── Entry methods ────────────────────────────────────────────────────────
    val biometricEnabled: Boolean = false,
    val pinEnabled: Boolean = false,

    // ── Lock switches (conditional on having an entry method) ────────────────
    /** Gate the Security Settings screen behind authentication. */
    val securitySettingsLockEnabled: Boolean = false,
    /** Gate the entire app on launch / resume. */
    val globalLockEnabled: Boolean = false,

    // ── PIN hash kept for verifyPin() used in change-PIN flows ───────────────
    val pinHash: String? = null,

    // ── Additional security features ─────────────────────────────────────────
    val stealthModeEnabled: Boolean = false,
    val killSwitchEnabled: Boolean = false,
    val autoLockEnabled: Boolean = true,

    // ── Session ──────────────────────────────────────────────────────────────
    val sessionTimeoutMinutes: Int = 0,
    val lastAuthenticated: Long = 0,

    // ── Lockout ──────────────────────────────────────────────────────────────
    val failedAttempts: Int = 0,
    val lastFailedAttempt: Long = 0,
    val lockoutEnabled: Boolean = true,
    val lockoutDurationMinutes: Int = 5,
    val maxFailedAttempts: Int = 5,

    val organizationLocked: Boolean = true,
    val lastUpdated: Long = System.currentTimeMillis()
)

// ── Auth result / type / session ─────────────────────────────────────────────

sealed class AuthResult {
    data object Success : AuthResult()
    data class Error(val message: String) : AuthResult()
    data object Cancelled : AuthResult()
    data object NotAvailable : AuthResult()
    data object LockedOut : AuthResult()
}

enum class AuthType { BIOMETRIC, PIN, NONE }

sealed class SessionState {
    data object Authenticated : SessionState()
    data object Unauthenticated : SessionState()
    data class Expired(val lastActive: Long) : SessionState()
    data class LockedOut(val remainingMinutes: Int) : SessionState()
}

enum class SecurityEventType {
    AUTH_SUCCESS, AUTH_FAILED_BIOMETRIC, AUTH_FAILED_PIN, AUTH_CANCELLED,
    SESSION_EXPIRED, LOCKOUT_TRIGGERED, SETTINGS_ACCESS_ATTEMPT,
    SETTINGS_ACCESS_GRANTED, TOGGLE_ATTEMPT_BLOCKED, KILL_SWITCH_ACTIVATED,
    STEALTH_MODE_ENABLED
}

data class SecurityEvent(
    val type: SecurityEventType,
    val timestamp: Long = System.currentTimeMillis(),
    val details: String? = null
)

// ── Extension functions ───────────────────────────────────────────────────────

fun SecurityConfig.hasAuthMethod(): Boolean = biometricEnabled || pinEnabled

fun SecurityConfig.requiresAuthentication(): Boolean = hasAuthMethod()

fun SecurityConfig.isSessionValid(): Boolean {
    if (sessionTimeoutMinutes <= 0) return true
    return System.currentTimeMillis() - lastAuthenticated < sessionTimeoutMinutes * 60_000L
}

fun SecurityConfig.isLockedOut(): Boolean {
    if (!lockoutEnabled || failedAttempts < maxFailedAttempts) return false
    return System.currentTimeMillis() - lastFailedAttempt < lockoutDurationMinutes * 60_000L
}

fun SecurityConfig.getLockoutRemainingMinutes(): Int {
    if (!isLockedOut()) return 0
    val remaining = lockoutDurationMinutes * 60_000L - (System.currentTimeMillis() - lastFailedAttempt)
    return (remaining / 60_000L).toInt().coerceAtLeast(1)
}

fun SecurityConfig.getAvailableAuthTypes(): List<AuthType> {
    val types = mutableListOf<AuthType>()
    if (biometricEnabled) types.add(AuthType.BIOMETRIC)
    if (pinEnabled) types.add(AuthType.PIN)
    if (types.isEmpty()) types.add(AuthType.NONE)
    return types
}
