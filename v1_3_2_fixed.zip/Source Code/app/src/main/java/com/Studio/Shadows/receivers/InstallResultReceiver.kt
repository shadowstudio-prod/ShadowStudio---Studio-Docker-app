package com.Studio.Shadows.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.util.Log

/**
 * Receives the result of a [PackageInstaller] session commit.
 *
 * STATUS_SUCCESS      — install succeeded. [PackageReplacedReceiver] will fire
 *                       next via ACTION_MY_PACKAGE_REPLACED, handle restart + cleanup there.
 * STATUS_PENDING_USER_ACTION — system needs explicit user confirmation. We
 *                       launch the provided confirmation activity automatically.
 * Anything else       — log the failure reason.
 */
class InstallResultReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(
            PackageInstaller.EXTRA_STATUS,
            PackageInstaller.STATUS_FAILURE
        )
        val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "No message"
        val apkPath = intent.getStringExtra(EXTRA_APK_PATH)

        when (status) {
            PackageInstaller.STATUS_SUCCESS -> {
                Log.i(TAG, "Install succeeded — waiting for MY_PACKAGE_REPLACED broadcast")
                // Cleanup and restart handled by PackageReplacedReceiver
            }

            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                // System requires the user to tap "Install" in a small dialog.
                // Launch it automatically — still far cleaner than the full
                // Package Installer app UI.
                Log.i(TAG, "Pending user action — launching confirmation dialog")
                val confirmIntent = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                confirmIntent?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(this)
                }
            }

            PackageInstaller.STATUS_FAILURE,
            PackageInstaller.STATUS_FAILURE_ABORTED,
            PackageInstaller.STATUS_FAILURE_BLOCKED,
            PackageInstaller.STATUS_FAILURE_CONFLICT,
            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE,
            PackageInstaller.STATUS_FAILURE_INVALID,
            PackageInstaller.STATUS_FAILURE_STORAGE -> {
                Log.e(TAG, "Install FAILED (status=$status): $message")
                // The APK is left in place so the user can retry manually.
            }

            else -> Log.w(TAG, "Unknown install status $status: $message")
        }
    }

    companion object {
        private const val TAG = "InstallResultReceiver"
        const val EXTRA_APK_PATH = "extra_apk_path"
    }
}
