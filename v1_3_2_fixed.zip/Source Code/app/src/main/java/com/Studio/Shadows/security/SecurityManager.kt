package com.Studio.Shadows.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.Studio.Shadows.data.local.SecurityConfigDao
import com.Studio.Shadows.data.model.AuthResult
import com.Studio.Shadows.data.model.AuthType
import com.Studio.Shadows.data.model.SecurityConfig
import com.Studio.Shadows.data.model.SessionState
import com.Studio.Shadows.data.model.getAvailableAuthTypes
import com.Studio.Shadows.data.model.getLockoutRemainingMinutes
import com.Studio.Shadows.data.model.hasAuthMethod
import com.Studio.Shadows.data.model.isLockedOut
import com.Studio.Shadows.data.model.isSessionValid
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

/**
 * SecurityManager — handles all authentication and security operations.
 *
 * Lock model:
 *   Entry methods: biometricEnabled, pinEnabled (dormant unless a lock is active)
 *   Lock switches: globalLockEnabled (app entry), securitySettingsLockEnabled (settings screen)
 *   Both locks require at least one entry method to be active.
 *
 * Authentication always uses [authenticateWithDeviceCredential], which presents the
 * standard Android system prompt (biometric + device PIN/pattern/password fallback).
 * No custom in-app PIN UI or hash verification is needed for entry.
 */
@Singleton
class SecurityManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val securityConfigDao: SecurityConfigDao,
    private val encryptedPrefs: EncryptedPreferenceManager
) {

    private val biometricManager = BiometricManager.from(context)

    fun getSecurityConfig(): Flow<SecurityConfig?> = securityConfigDao.getConfigFlow()

    // ── Biometric availability ────────────────────────────────────────────────

    fun isBiometricAvailable(): Boolean =
        biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
                BiometricManager.BIOMETRIC_SUCCESS

    fun canUseBiometric(): Boolean = isBiometricAvailable()

    fun getBiometricStatus(): BiometricStatus =
        when (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)) {
            BiometricManager.BIOMETRIC_SUCCESS                       -> BiometricStatus.AVAILABLE
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE            -> BiometricStatus.NO_HARDWARE
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE         -> BiometricStatus.HARDWARE_UNAVAILABLE
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED          -> BiometricStatus.NOT_ENROLLED
            BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED -> BiometricStatus.SECURITY_UPDATE_REQUIRED
            else                                                     -> BiometricStatus.UNKNOWN
        }

    // ── Authentication prompts ────────────────────────────────────────────────

    /**
     * Native Android Device Credentials prompt.
     * Handles biometric + device PIN/pattern/password in one system UI.
     * Used for both app entry and security settings access.
     */
    fun authenticateWithDeviceCredential(
        activity: FragmentActivity,
        onResult: (AuthResult) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(context)
        val prompt = BiometricPrompt(
            activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onResult(AuthResult.Success)
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onResult(
                        when (errorCode) {
                            BiometricPrompt.ERROR_USER_CANCELED,
                            BiometricPrompt.ERROR_NEGATIVE_BUTTON -> AuthResult.Cancelled
                            BiometricPrompt.ERROR_LOCKOUT,
                            BiometricPrompt.ERROR_LOCKOUT_PERMANENT -> AuthResult.LockedOut
                            else -> AuthResult.Error(errString.toString())
                        }
                    )
                }
                override fun onAuthenticationFailed() { /* prompt handles retry feedback */ }
            }
        )

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Authentication Required")
            .setSubtitle("Verify your identity to access ShadowStudio")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        prompt.authenticate(promptInfo)
    }

    /**
     * Biometric-only prompt (used internally; falls back to device credential via
     * [authenticateWithDeviceCredential] in practice).
     */
    fun authenticateWithBiometric(
        activity: FragmentActivity,
        onResult: (AuthResult) -> Unit
    ) = authenticateWithDeviceCredential(activity, onResult)

    // ── PIN helpers (retained for change-PIN verification) ───────────────────

    suspend fun verifyPin(pin: String): AuthResult {
        val config = securityConfigDao.getConfig()
            ?: return AuthResult.Error("Security config not found")
        if (config.isLockedOut()) return AuthResult.LockedOut
        val storedHash = config.pinHash ?: return AuthResult.Error("PIN not set")
        val inputHash = hashPin(pin)
        return if (inputHash == storedHash) {
            securityConfigDao.resetFailedAttempts()
            securityConfigDao.updateLastAuthenticated(System.currentTimeMillis())
            AuthResult.Success
        } else {
            val newAttempts = config.failedAttempts + 1
            securityConfigDao.updateFailedAttempts(newAttempts, System.currentTimeMillis())
            AuthResult.Error("Incorrect PIN")
        }
    }

    suspend fun setPin(pin: String): Result<Unit> {
        if (pin.length < 4) return Result.failure(Exception("PIN must be at least 4 digits"))
        securityConfigDao.setPinEnabled(true, hashPin(pin))
        return Result.success(Unit)
    }

    suspend fun changePin(currentPin: String, newPin: String): Result<Unit> {
        val config = securityConfigDao.getConfig()
            ?: return Result.failure(Exception("Security config not found"))
        val currentHash = config.pinHash
            ?: return Result.failure(Exception("PIN not set"))
        if (hashPin(currentPin) != currentHash)
            return Result.failure(Exception("Current PIN is incorrect"))
        if (newPin.length < 4)
            return Result.failure(Exception("New PIN must be at least 4 digits"))
        securityConfigDao.setPinEnabled(true, hashPin(newPin))
        return Result.success(Unit)
    }

    // ── Lock checks ───────────────────────────────────────────────────────────

    /**
     * Whether the app should be locked at entry.
     * True only when globalLockEnabled AND at least one entry method is active.
     */
    suspend fun isAppLockRequired(): Boolean {
        val config = securityConfigDao.getConfig() ?: return false
        return config.globalLockEnabled && config.hasAuthMethod()
    }

    /**
     * Whether Security Settings access should be blocked.
     * True only when securitySettingsLockEnabled AND at least one entry method is active.
     */
    suspend fun isSecuritySettingsLockRequired(): Boolean {
        val config = securityConfigDao.getConfig() ?: return false
        return config.securitySettingsLockEnabled && config.hasAuthMethod()
    }

    suspend fun isAuthenticationRequired(): Boolean {
        val config = securityConfigDao.getConfig() ?: return false
        if (!config.hasAuthMethod()) return false
        if (config.isLockedOut()) return true
        return !config.isSessionValid()
    }

    suspend fun getSessionState(): SessionState {
        val config = securityConfigDao.getConfig()
            ?: return SessionState.Unauthenticated
        if (config.isLockedOut()) return SessionState.LockedOut(config.getLockoutRemainingMinutes())
        if (!config.hasAuthMethod()) return SessionState.Authenticated
        return if (config.isSessionValid()) SessionState.Authenticated
               else SessionState.Expired(config.lastAuthenticated)
    }

    // ── Config mutations ──────────────────────────────────────────────────────

    suspend fun recordAuthentication() {
        securityConfigDao.resetFailedAttempts()
        securityConfigDao.updateLastAuthenticated(System.currentTimeMillis())
    }

    suspend fun setGlobalLockEnabled(enabled: Boolean) =
        securityConfigDao.setGlobalLockEnabled(enabled)

    suspend fun setSecuritySettingsLockEnabled(enabled: Boolean) =
        securityConfigDao.setSecuritySettingsLockEnabled(enabled)

    suspend fun setBiometricEnabled(enabled: Boolean) =
        securityConfigDao.setBiometricEnabled(enabled)

    suspend fun setPinEnabled(enabled: Boolean) {
        if (!enabled) securityConfigDao.setPinEnabled(false, null)
        else securityConfigDao.setPinEnabled(true, null) // hash set separately via setPin()
    }

    suspend fun setStealthModeEnabled(enabled: Boolean) =
        securityConfigDao.setStealthModeEnabled(enabled)

    suspend fun setKillSwitchEnabled(enabled: Boolean) =
        securityConfigDao.setKillSwitchEnabled(enabled)

    suspend fun setAutoLockEnabled(enabled: Boolean) =
        securityConfigDao.setAutoLockEnabled(enabled)

    suspend fun setSessionTimeout(minutes: Int) =
        securityConfigDao.setSessionTimeout(minutes)

    suspend fun initializeDefaultConfig() {
        if (securityConfigDao.getConfig() == null)
            securityConfigDao.insertConfig(SecurityConfig())
    }

    suspend fun getAvailableAuthTypes(): List<AuthType> =
        securityConfigDao.getConfig()?.getAvailableAuthTypes() ?: listOf(AuthType.NONE)

    suspend fun isOrganizationLocked(): Boolean =
        securityConfigDao.getConfig()?.organizationLocked ?: true

    suspend fun setOrganizationLocked(locked: Boolean) {
        val config = securityConfigDao.getConfig()
        if (config != null) securityConfigDao.updateConfig(config.copy(organizationLocked = locked))
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun hashPin(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(pin.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}

enum class BiometricStatus {
    AVAILABLE, NO_HARDWARE, HARDWARE_UNAVAILABLE, NOT_ENROLLED,
    SECURITY_UPDATE_REQUIRED, UNKNOWN
}
