package com.Studio.Shadows.ui.theme

import androidx.compose.ui.graphics.Color

// ==================== SHADOW THEME - PRIMARY COLORS ====================

val ShadowBackground = Color(0xFF121212)
val ShadowBackgroundVariant = Color(0xFF1E1E1E)
val ShadowSurface = Color(0xFF242424)
val ShadowSurfaceVariant = Color(0xFF2D2D2D)
val ShadowSurfaceElevated = Color(0xFF333333)

val ShadowPrimary = Color(0xFF6366F1)
val ShadowPrimaryVariant = Color(0xFF4F46E5)
val ShadowPrimaryContainer = Color(0xFF312E81)
val OnShadowPrimary = Color(0xFFFFFFFF)

val ShadowSecondary = Color(0xFF14B8A6)
val ShadowSecondaryVariant = Color(0xFF0D9488)
val ShadowSecondaryContainer = Color(0xFF134E4A)
val OnShadowSecondary = Color(0xFF000000)

val ShadowTertiary = Color(0xFFD946EF)
val ShadowTertiaryVariant = Color(0xFFC026D3)
val ShadowTertiaryContainer = Color(0xFF86198F)
val OnShadowTertiary = Color(0xFFFFFFFF)

val OnShadowBackground = Color(0xFFFFFFFF)
val OnShadowSurface = Color(0xFFFFFFFF)
val OnShadowSurfaceVariant = Color(0xFFB3B3B3)
val OnShadowSurfaceDisabled = Color(0xFF666666)

val ShadowSuccess = Color(0xFF22C55E)
val ShadowSuccessContainer = Color(0xFF14532D)
val OnShadowSuccess = Color(0xFFFFFFFF)

val ShadowWarning = Color(0xFFF59E0B)
val ShadowWarningContainer = Color(0xFF78350F)
val OnShadowWarning = Color(0xFF000000)

val ShadowError = Color(0xFFEF4444)
val ShadowErrorContainer = Color(0xFF7F1D1D)
val OnShadowError = Color(0xFFFFFFFF)

val ShadowInfo = Color(0xFF3B82F6)
val ShadowInfoContainer = Color(0xFF1E3A8A)
val OnShadowInfo = Color(0xFFFFFFFF)

val ShadowOutline = Color(0xFF525252)
val ShadowOutlineVariant = Color(0xFF404040)
val ShadowDivider = Color(0xFF333333)

val ShadowScrim = Color(0xCC000000)
val ShadowOverlay = Color(0x99000000)
val ShadowRipple = Color(0x33FFFFFF)

// ── Existing service colours ──────────────────────────────────────────────────

val ServiceImmich        = Color(0xFFFA7070)
val ServiceRipper        = Color(0xFFF59E0B)
val ServiceNginx         = Color(0xFF009639)
val ServiceRomm          = Color(0xFF8B5CF6)
val ServiceWebUI         = Color(0xFF14B8A6)
val ServiceHomeAssistant = Color(0xFF03A9F4)
val ServiceHomepage      = Color(0xFF6366F1)
val ServiceJellyfin      = Color(0xFF00A4DC)
val ServiceN8N           = Color(0xFFFF6D5A)
val ServiceBeszel        = Color(0xFF10B981)

// ── New App colours ───────────────────────────────────────────────────────────

val ServiceCrafty4       = Color(0xFF4CAF50)   // Minecraft-ish green
val ServiceTraccar       = Color(0xFF2196F3)   // Blue (tracking)

// ── New Service colours ───────────────────────────────────────────────────────

val ServiceBeszelAgent   = Color(0xFF0D9488)   // Teal (monitoring agent)
val ServiceCloudflared   = Color(0xFFF38020)   // Cloudflare orange
val ServiceOllama        = Color(0xFF7C3AED)   // Purple (AI/LLM)
val ServiceSsupdater     = Color(0xFF64748B)   // Slate gray (file manager)
val ServiceTailscale     = Color(0xFF2563EB)   // Tailscale blue
val ServiceTalkAio       = Color(0xFF0082C9)   // Nextcloud blue
val ServicePihole        = Color(0xFFCC0000)   // Pi-Hole red
val ServiceVaultWarden   = Color(0xFF175DDC)   // Bitwarden/VaultWarden blue

/**
 * Returns the accent colour for a given service ID.
 * Falls back to [ShadowPrimary] for any unrecognised ID.
 */
fun getServiceColor(serviceId: String): Color = when (serviceId) {
    // Apps
    "immich"        -> ServiceImmich
    "ripper"        -> ServiceRipper
    "nginx"         -> ServiceNginx
    "romm"          -> ServiceRomm
    "webui"         -> ServiceWebUI
    "homeassistant" -> ServiceHomeAssistant
    "homepage"      -> ServiceHomepage
    "jellyfin"      -> ServiceJellyfin
    "n8n"           -> ServiceN8N
    "beszel"        -> ServiceBeszel
    "crafty4"       -> ServiceCrafty4
    "traccar"       -> ServiceTraccar
    // Services
    "beszel-agent"  -> ServiceBeszelAgent
    "cloudflared"   -> ServiceCloudflared
    "ollama"        -> ServiceOllama
    "ssupdater"     -> ServiceSsupdater
    "tailscale"     -> ServiceTailscale
    "talk-aio"      -> ServiceTalkAio
    "pihole"        -> ServicePihole
    "vaultwarden"   -> ServiceVaultWarden
    else            -> ShadowPrimary
}
