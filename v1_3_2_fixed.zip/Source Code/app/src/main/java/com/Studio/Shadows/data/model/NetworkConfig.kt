package com.Studio.Shadows.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Global network configuration for ShadowStudio.
 */
@Entity(tableName = "network_config")
data class GlobalNetworkConfig(
    @PrimaryKey
    val id: Int = 1,
    val primaryHost: String = "192.168.1.10",
    val backupHost: String = "100.79.28.41",
    val connectionTimeoutMs: Int = 10000,
    val readTimeoutMs: Int = 30000,
    val failoverEnabled: Boolean = true,
    val lastUpdated: Long = System.currentTimeMillis()
)

/**
 * Per-app network configuration.
 *
 * v6: Added isHidden, sortIndex.
 * v7: Added serviceType ("APP" or "SERVICE") to allow filtered queries
 *     for the new Services screen and the Network Settings dropdowns.
 *
 * port defaults to 0 for new entries — the user configures the real port
 * in Network Settings. buildUrl() returns isValid = false when port == 0
 * so unconfigured services fail gracefully.
 */
@Entity(tableName = "app_network_config")
data class AppNetworkConfig(
    @PrimaryKey
    val appId: String,
    val protocol: String = "HTTP",
    val port: Int = 0,
    val customHost: String? = null,
    val customPath: String = "",
    val useGlobalHosts: Boolean = true,
    val isEnabled: Boolean = true,
    val lastUpdated: Long = System.currentTimeMillis(),
    val sortIndex: Int = 0,
    val isHidden: Boolean = false,
    // ── v7 ────────────────────────────────────────────────────────────────────
    val serviceType: String = "APP"  // "APP" or "SERVICE"
)

data class ServiceUrl(
    val appId: String,
    val url: String,
    val isUsingBackup: Boolean = false,
    val isValid: Boolean = true
)

sealed class ConnectionResult {
    data class Success(
        val responseTimeMs: Long,
        val usingBackupHost: Boolean = false
    ) : ConnectionResult()

    data class Error(
        val exception: Throwable,
        val message: String,
        val isTimeout: Boolean = false
    ) : ConnectionResult()

    data object Loading : ConnectionResult()
}

fun AppNetworkConfig.buildUrl(host: String, globalConfig: GlobalNetworkConfig): ServiceUrl {
    if (host.isBlank()) return ServiceUrl(appId, "", isValid = false)
    // Port 0 means not yet configured — return invalid so callers handle gracefully.
    if (port == 0) return ServiceUrl(appId, "", isValid = false)
    val proto = protocol.lowercase()
    val url = if (customPath.isNotEmpty()) "$proto://$host:$port/$customPath"
              else "$proto://$host:$port"
    return ServiceUrl(appId, url)
}

/**
 * Default configurations for all entries.
 *
 * Port = 0 for new items — the user will configure the real port in
 * Network Settings. Existing items that had real ports keep them so
 * existing installs are not disrupted.
 *
 * sortIndex:
 *   0–9   : Apps (alphabetical within the Apps section)
 *   10–19 : Services (alphabetical within the Services section)
 *   20+   : Legacy entries preserved from previous versions
 */
object DefaultAppConfigs {
    fun getDefaults(): List<AppNetworkConfig> = listOf(

        // ── Apps ──────────────────────────────────────────────────────────────
        AppNetworkConfig("beszel",        "HTTP", 0, sortIndex = 0,  serviceType = "APP"),
        AppNetworkConfig("crafty4",       "HTTP", 0, sortIndex = 1,  serviceType = "APP"),
        AppNetworkConfig("homeassistant", "HTTP", 0, sortIndex = 2,  serviceType = "APP"),
        AppNetworkConfig("homepage",      "HTTP", 0, sortIndex = 3,  serviceType = "APP"),
        AppNetworkConfig("immich",        "HTTP", 0, sortIndex = 4,  serviceType = "APP"),
        AppNetworkConfig("jellyfin",      "HTTP", 0, sortIndex = 5,  serviceType = "APP"),
        AppNetworkConfig("webui",         "HTTP", 0, sortIndex = 6,  serviceType = "APP"),
        AppNetworkConfig("n8n",           "HTTP", 0, sortIndex = 7,  serviceType = "APP"),
        AppNetworkConfig("nginx",         "HTTP", 0, sortIndex = 8,  serviceType = "APP"),
        AppNetworkConfig("traccar",       "HTTP", 0, sortIndex = 9,  serviceType = "APP"),

        // ── Services ──────────────────────────────────────────────────────────
        AppNetworkConfig("beszel-agent",  "HTTP", 0, sortIndex = 10, serviceType = "SERVICE"),
        AppNetworkConfig("cloudflared",   "HTTP", 0, sortIndex = 11, serviceType = "SERVICE"),
        AppNetworkConfig("ollama",        "HTTP", 0, sortIndex = 12, serviceType = "SERVICE"),
        AppNetworkConfig("ssupdater",     "HTTP", 0, sortIndex = 13, serviceType = "SERVICE"),
        AppNetworkConfig("tailscale",     "HTTP", 0, sortIndex = 14, serviceType = "SERVICE"),
        AppNetworkConfig("talk-aio",      "HTTP", 0, sortIndex = 15, serviceType = "SERVICE"),
        AppNetworkConfig("pihole",        "HTTP", 0, sortIndex = 16, serviceType = "SERVICE"),
        AppNetworkConfig("vaultwarden",   "HTTP", 0, sortIndex = 17, serviceType = "SERVICE"),

        // ── Legacy (preserved from v1) ────────────────────────────────────────
        AppNetworkConfig("ripper",        "HTTP", 0, sortIndex = 20, serviceType = "APP"),
        AppNetworkConfig("romm",          "HTTP", 0, sortIndex = 21, serviceType = "APP"),
    )
}
