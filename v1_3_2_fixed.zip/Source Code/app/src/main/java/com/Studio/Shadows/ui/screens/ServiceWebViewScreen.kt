package com.Studio.Shadows.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.http.SslError
import android.view.ViewGroup
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import com.Studio.Shadows.R
import com.Studio.Shadows.ui.theme.ShadowBackground
import com.Studio.Shadows.ui.theme.ShadowError
import com.Studio.Shadows.ui.theme.ShadowPrimary
import com.Studio.Shadows.ui.theme.ShadowSurface
import com.Studio.Shadows.ui.viewmodel.ServiceWebViewViewModel

/**
 * Service WebView Screen.
 *
 * SSL certificate errors are bypassed for all services via [onReceivedSslError].
 * All hosts are user-configured, private-network / VPN addresses — the user has
 * explicitly supplied and verified the host in Network Settings — so proceeding
 * through self-signed / private-CA certificate errors is intentional and safe.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ServiceWebViewScreen(
    serviceId: String,
    viewModel: ServiceWebViewViewModel = hiltViewModel()
) {
    val serviceUrl by viewModel.getServiceUrl(serviceId).collectAsState(initial = null)
    var isLoading by remember { mutableStateOf(true) }
    var loadingProgress by remember { mutableFloatStateOf(0f) }
    var hasError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var webView by remember { mutableStateOf<WebView?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ShadowBackground)
    ) {
        when {
            serviceUrl == null || serviceUrl?.url.isNullOrBlank() -> {
                ErrorView(
                    message = "Service URL not configured. Please check network settings.",
                    onRetry = { viewModel.refreshUrl(serviceId) }
                )
            }
            hasError -> {
                ErrorView(
                    message = errorMessage,
                    onRetry = {
                        hasError = false
                        webView?.reload()
                    }
                )
            }
            else -> {
                Column(modifier = Modifier.fillMaxSize()) {
                    if (isLoading && loadingProgress < 100) {
                        LinearProgressIndicator(
                            progress = { loadingProgress / 100f },
                            modifier = Modifier.fillMaxWidth(),
                            color = ShadowPrimary
                        )
                    }

                    AndroidView(
                        factory = { context ->
                            WebView(context).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    databaseEnabled = true
                                    setSupportZoom(true)
                                    builtInZoomControls = true
                                    displayZoomControls = false
                                    useWideViewPort = true
                                    loadWithOverviewMode = true
                                    // Override the "wv" WebView UA token so servers serve
                                    // their full JS bundles rather than noscript fallbacks.
                                    userAgentString = "Mozilla/5.0 (Linux; Android 10; Mobile) " +
                                            "AppleWebKit/537.36 (KHTML, like Gecko) " +
                                            "Chrome/124.0.0.0 Mobile Safari/537.36"
                                }
                                webChromeClient = object : WebChromeClient() {
                                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                        loadingProgress = newProgress.toFloat()
                                    }
                                }
                                webViewClient = object : WebViewClient() {

                                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                        isLoading = true
                                        hasError = false
                                    }

                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        isLoading = false
                                    }

                                    override fun onReceivedError(
                                        view: WebView?,
                                        request: WebResourceRequest?,
                                        error: WebResourceError?
                                    ) {
                                        if (request?.isForMainFrame == true) {
                                            isLoading = false
                                            hasError = true
                                            errorMessage = "Failed to load page: ${error?.description}"
                                        }
                                    }

                                    /**
                                     * Bypass SSL certificate errors for all services.
                                     *
                                     * All hosts in ShadowStudio are user-configured private-network
                                     * or VPN addresses. Self-signed and private-CA certificates are
                                     * common in self-hosted environments and are safe to accept here
                                     * because the user has explicitly set and verified each host.
                                     */
                                    @SuppressLint("WebViewClientOnReceivedSslError")
                                    override fun onReceivedSslError(
                                        view: WebView?,
                                        handler: SslErrorHandler?,
                                        error: SslError?
                                    ) {
                                        handler?.proceed()
                                    }
                                }
                                webView = this
                                loadUrl(serviceUrl?.url ?: "")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    )
                }

                if (isLoading) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = ShadowPrimary)
                    }
                }
            }
        }

        if (!isLoading && !hasError && serviceUrl?.url != null) {
            IconButton(
                onClick = { webView?.reload() },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .clip(RoundedCornerShape(50))
                    .background(ShadowSurface)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = stringResource(R.string.webview_refresh),
                    tint = ShadowPrimary
                )
            }
        }
    }
}

@Composable
private fun ErrorView(message: String, onRetry: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = stringResource(R.string.webview_error),
                style = MaterialTheme.typography.titleLarge,
                color = ShadowError
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = ShadowPrimary)
            ) {
                Text(stringResource(R.string.webview_reload))
            }
        }
    }
}
