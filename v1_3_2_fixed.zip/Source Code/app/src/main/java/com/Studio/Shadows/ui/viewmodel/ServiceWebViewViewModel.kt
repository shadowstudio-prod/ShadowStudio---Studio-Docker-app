package com.Studio.Shadows.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.Studio.Shadows.data.model.ServiceUrl
import com.Studio.Shadows.data.repository.NetworkConfigRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for Service WebView Screen
 */
@HiltViewModel
class ServiceWebViewViewModel @Inject constructor(
    private val networkConfigRepository: NetworkConfigRepository
) : ViewModel() {

    private val _serviceUrls = MutableStateFlow<Map<String, ServiceUrl>>(emptyMap())

    init {
        viewModelScope.launch {
            networkConfigRepository.initializeDefaults()
        }
    }

    /**
     * Get service URL as a Flow
     */
    fun getServiceUrl(serviceId: String): Flow<ServiceUrl> = flow {
        val url = networkConfigRepository.buildServiceUrlWithFailover(serviceId)
        emit(url)
    }

    /**
     * Refresh service URL
     */
    fun refreshUrl(serviceId: String) {
        viewModelScope.launch {
            val url = networkConfigRepository.buildServiceUrlWithFailover(serviceId)
            _serviceUrls.value = _serviceUrls.value.toMutableMap().apply {
                put(serviceId, url)
            }
        }
    }
}
