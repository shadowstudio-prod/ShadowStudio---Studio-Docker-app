package com.Studio.Shadows.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TimePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.Studio.Shadows.R
import com.Studio.Shadows.ui.theme.ShadowBackground
import com.Studio.Shadows.ui.theme.ShadowPrimary
import com.Studio.Shadows.ui.theme.ShadowSurface
import com.Studio.Shadows.ui.viewmodel.UpdateViewModel

// ─────────────────────────────────────────────────────────────────────────────
// Wrapper
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun UpdateScreenWrapper(viewModel: UpdateViewModel = viewModel()) {
    val updateProgress    by viewModel.updateProgress.collectAsState()
    val rollbackProgress  by viewModel.rollbackProgress.collectAsState()
    val developerLogs     by viewModel.developerLogs.collectAsState()
    val releaseNotes      by viewModel.releaseNotes.collectAsState()
    val latestVersionName by viewModel.latestVersionName.collectAsState()
    val isCheckingUpdate  by viewModel.isCheckingUpdate.collectAsState()
    val isBusy            by viewModel.isBusy.collectAsState()
    val autoUpdateEnabled by viewModel.autoUpdateEnabled.collectAsState()
    val scheduledHour     by viewModel.scheduledHour.collectAsState()
    val scheduledMinute   by viewModel.scheduledMinute.collectAsState()

    UpdateScreen(
        currentVersionName   = stringResource(R.string.app_version),
        latestVersionName    = latestVersionName.ifBlank { null },
        releaseNotes         = releaseNotes,
        isCheckingUpdate     = isCheckingUpdate,
        isBusy               = isBusy,
        updateProgress       = updateProgress,
        rollbackProgress     = rollbackProgress,
        developerLogs        = developerLogs,
        autoUpdateEnabled    = autoUpdateEnabled,
        scheduledHour        = scheduledHour,
        scheduledMinute      = scheduledMinute,
        onCheckForUpdate     = { viewModel.checkForUpdate() },
        onStartUpdate        = { viewModel.startUpdate() },
        onStartRollback      = { viewModel.startRollback() },
        onCancelProcess      = { viewModel.cancelDownload() },
        onAutoUpdateToggle   = { viewModel.setAutoUpdateEnabled(it) },
        onScheduledTimeChange= { h, m -> viewModel.setScheduledTime(h, m) }
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Main Screen
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpdateScreen(
    currentVersionName   : String,
    latestVersionName    : String?,
    releaseNotes         : String,
    isCheckingUpdate     : Boolean,
    isBusy               : Boolean,
    updateProgress       : Float?,
    rollbackProgress     : Float?,
    developerLogs        : List<String>,
    autoUpdateEnabled    : Boolean,
    scheduledHour        : Int,
    scheduledMinute      : Int,
    onCheckForUpdate     : () -> Unit,
    onStartUpdate        : () -> Unit,
    onStartRollback      : () -> Unit,
    onCancelProcess      : () -> Unit,
    onAutoUpdateToggle   : (Boolean) -> Unit,
    onScheduledTimeChange: (Int, Int) -> Unit
) {
    var detailsExpanded  by remember { mutableStateOf(false) }
    var logsExpanded     by remember { mutableStateOf(false) }
    var showTimePicker   by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ShadowBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        // ── Version pills ─────────────────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            VersionPill(label = "Installed", version = currentVersionName)
            if (latestVersionName != null && latestVersionName != currentVersionName) {
                VersionPill(label = "Available", version = latestVersionName, highlight = true)
            }
        }

        // ── Check for Update button ───────────────────────────────────────────
        OutlinedButton(
            onClick  = onCheckForUpdate,
            enabled  = !isBusy && !isCheckingUpdate,
            modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(10.dp),
            border   = androidx.compose.foundation.BorderStroke(
                1.dp,
                ShadowPrimary.copy(alpha = if (isBusy || isCheckingUpdate) 0.3f else 0.6f)
            )
        ) {
            if (isCheckingUpdate) {
                androidx.compose.material3.CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    strokeWidth = 2.dp,
                    color = ShadowPrimary
                )
                Spacer(Modifier.width(8.dp))
                Text("Checking…", color = ShadowPrimary)
            } else {
                Icon(Icons.Default.Refresh, null, tint = ShadowPrimary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.update_check), color = ShadowPrimary)
            }
        }

        // ── Auto-Update card ──────────────────────────────────────────────────
        AutoUpdateCard(
            enabled             = autoUpdateEnabled,
            scheduledHour       = scheduledHour,
            scheduledMinute     = scheduledMinute,
            onToggle            = onAutoUpdateToggle,
            onChangeTimeClick   = { showTimePicker = true }
        )

        // ── Manual Update card ────────────────────────────────────────────────
        ActionCard(
            icon        = Icons.Default.SystemUpdate,
            title       = stringResource(R.string.update_download),
            description = "Download and install the latest release immediately.",
            actionLabel = stringResource(R.string.update_download),
            progress    = updateProgress,
            enabled     = !isBusy,
            onAction    = onStartUpdate,
            onCancel    = onCancelProcess
        )

        // ── Rollback card ─────────────────────────────────────────────────────
        ActionCard(
            icon        = Icons.Default.History,
            title       = stringResource(R.string.action_rollback),
            description = "Revert to the previous stable release.",
            actionLabel = stringResource(R.string.action_rollback),
            progress    = rollbackProgress,
            enabled     = !isBusy,
            onAction    = onStartRollback,
            onCancel    = onCancelProcess,
            isRollback  = true
        )

        // ── Update Details (collapsible) ──────────────────────────────────────
        CollapsibleCard(
            title    = "Update Details",
            expanded = detailsExpanded,
            onToggle = { detailsExpanded = !detailsExpanded }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DetailRow("Installed version", currentVersionName)
                if (latestVersionName != null) DetailRow("Latest version", latestVersionName)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Release notes",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    releaseNotes,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    lineHeight = 22.sp
                )
            }
        }

        // ── Developer Logs (collapsible) ──────────────────────────────────────
        CollapsibleCard(
            title    = "Developer Logs",
            expanded = logsExpanded,
            onToggle = { logsExpanded = !logsExpanded }
        ) {
            val reversed = developerLogs.reversed()
            if (reversed.isEmpty()) {
                Text(
                    "No activity yet.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                ) {
                    itemsIndexed(reversed) { _, log ->
                        Text(
                            text = log,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(40.dp))
    }

    // ── Time Picker Dialog ────────────────────────────────────────────────────
    if (showTimePicker) {
        val timePickerState = rememberTimePickerState(
            initialHour   = scheduledHour,
            initialMinute = scheduledMinute,
            is24Hour      = true
        )
        TimePickerDialog(
            state    = timePickerState,
            onDismiss = { showTimePicker = false },
            onConfirm = {
                onScheduledTimeChange(timePickerState.hour, timePickerState.minute)
                showTimePicker = false
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Auto-Update Card
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun AutoUpdateCard(
    enabled           : Boolean,
    scheduledHour     : Int,
    scheduledMinute   : Int,
    onToggle          : (Boolean) -> Unit,
    onChangeTimeClick : () -> Unit
) {
    val timeLabel = "%02d:%02d".format(scheduledHour, scheduledMinute)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ShadowPrimary.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
        shape          = RoundedCornerShape(16.dp),
        color          = ShadowSurface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(20.dp)) {

            // Header row — toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(ShadowPrimary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Schedule,
                            contentDescription = null,
                            tint = ShadowPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            "Auto-Update",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            if (enabled) "Installs daily at $timeLabel"
                            else "Disabled — updates are manual only",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked  = enabled,
                    onCheckedChange = onToggle,
                    colors   = SwitchDefaults.colors(
                        checkedThumbColor  = Color.White,
                        checkedTrackColor  = ShadowPrimary,
                        uncheckedThumbColor = Color.White
                    )
                )
            }

            // Scheduled time row (only shown when enabled)
            AnimatedVisibility(visible = enabled) {
                Column {
                    Spacer(Modifier.height(16.dp))
                    androidx.compose.material3.HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    "Scheduled install time",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    "Daily at $timeLabel (24-hour)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        TextButton(onClick = onChangeTimeClick) {
                            Text("Change", color = ShadowPrimary)
                        }
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Time Picker Dialog
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimePickerDialog(
    state    : TimePickerState,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape  = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = ShadowSurface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Set Auto-Update Time",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp)
                )
                TimePicker(state = state)
                Spacer(Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(stringResource(R.string.dialog_cancel))
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = onConfirm,
                        colors  = ButtonDefaults.buttonColors(containerColor = ShadowPrimary)
                    ) {
                        Text(stringResource(R.string.dialog_ok))
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Action Card (Update / Rollback)
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun ActionCard(
    icon        : ImageVector,
    title       : String,
    description : String,
    actionLabel : String,
    progress    : Float?,
    enabled     : Boolean,
    onAction    : () -> Unit,
    onCancel    : () -> Unit,
    isRollback  : Boolean = false
) {
    val accentColor = if (isRollback) MaterialTheme.colorScheme.secondary else ShadowPrimary

    Surface(
        modifier  = Modifier
            .fillMaxWidth()
            .border(1.dp, accentColor.copy(alpha = 0.25f), RoundedCornerShape(16.dp)),
        shape          = RoundedCornerShape(16.dp),
        color          = ShadowSurface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accentColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = accentColor, modifier = Modifier.size(22.dp))
                }
                Column {
                    Text(
                        title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            if (progress != null) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LinearProgressIndicator(
                            progress   = { progress },
                            modifier   = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(50)),
                            color      = accentColor,
                            trackColor = accentColor.copy(alpha = 0.15f)
                        )
                        IconButton(onClick = onCancel, modifier = Modifier.size(32.dp)) {
                            Icon(
                                Icons.Default.Close,
                                stringResource(R.string.cancel_download),
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Text(
                        "${(progress * 100).toInt()}%  —  downloading…",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Button(
                    onClick  = onAction,
                    enabled  = enabled,
                    modifier = Modifier.fillMaxWidth(),
                    colors   = ButtonDefaults.buttonColors(containerColor = accentColor),
                    shape    = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(actionLabel, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Collapsible Card
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CollapsibleCard(
    title    : String,
    expanded : Boolean,
    onToggle : () -> Unit,
    content  : @Composable () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                RoundedCornerShape(16.dp)
            )
            .animateContentSize(tween(250))
            .clickable(onClick = onToggle),
        shape          = RoundedCornerShape(16.dp),
        color          = ShadowSurface,
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Icon(
                    if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    if (expanded) "Collapse" else "Expand",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
            AnimatedVisibility(
                visible = expanded,
                enter   = expandVertically(tween(250)),
                exit    = shrinkVertically(tween(200))
            ) {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    content()
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun VersionPill(label: String, version: String, highlight: Boolean = false) {
    val bg     = if (highlight) ShadowPrimary.copy(0.15f) else MaterialTheme.colorScheme.surfaceVariant
    val border = if (highlight) ShadowPrimary.copy(0.5f)  else Color.Transparent
    val text   = if (highlight) ShadowPrimary              else MaterialTheme.colorScheme.onSurfaceVariant

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = text.copy(0.7f))
        Text("v$version", style = MaterialTheme.typography.labelMedium,
             fontWeight = FontWeight.Bold, color = text)
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label,
             style = MaterialTheme.typography.bodySmall,
             color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value,
             style = MaterialTheme.typography.bodySmall,
             fontWeight = FontWeight.Medium,
             color = MaterialTheme.colorScheme.onBackground)
    }
}
