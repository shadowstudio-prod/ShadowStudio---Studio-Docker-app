package com.Studio.Shadows.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.Studio.Shadows.data.model.AppModel
import com.Studio.Shadows.data.model.AppNetworkConfig
import com.Studio.Shadows.data.model.AvailableServices
import com.Studio.Shadows.data.repository.NetworkConfigRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Combines the static [AppModel] metadata with the persisted [AppNetworkConfig]
 * so the Manage Services screen has everything it needs in one object.
 */
data class ServiceManageItem(
    val appModel: AppModel,
    val config: AppNetworkConfig
)

/**
 * ViewModel for the Manage Services screen.
 *
 * Responsibilities:
 *  - Exposes ALL services (including hidden) ordered by [AppNetworkConfig.sortIndex].
 *  - Toggles [AppNetworkConfig.isHidden] for a given service.
 *  - Moves a service up or down in the list and persists the new [sortIndex] values.
 */
@HiltViewModel
class ManageServicesViewModel @Inject constructor(
    private val repository: NetworkConfigRepository
) : ViewModel() {

    /**
     * All services (hidden and visible) merged with their static [AppModel] data,
     * sorted by [AppNetworkConfig.sortIndex] ascending.
     *
     * Services without a matching [AppModel] (e.g. stale DB rows) are filtered out
     * so the UI never shows an orphaned entry.
     */
    val services: StateFlow<List<ServiceManageItem>> = repository
        .getAllAppConfigsFlow()
        .map { configs ->
            configs.mapNotNull { config ->
                val appModel = AvailableServices.getServiceById(config.appId)
                    ?: return@mapNotNull null
                ServiceManageItem(appModel = appModel, config = config)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    // ── Visibility ────────────────────────────────────────────────────────────

    /**
     * Toggles the hidden state for [appId].
     * The change propagates immediately to Home, Drawer, and Network Settings
     * because those screens consume [getVisibleAppConfigsFlow].
     */
    fun setHidden(appId: String, isHidden: Boolean) {
        viewModelScope.launch {
            repository.setAppHidden(appId, isHidden)
        }
    }

    // ── Sort Order ────────────────────────────────────────────────────────────

    /**
     * Moves the service at [index] one position up (toward index 0).
     * Swaps [AppNetworkConfig.sortIndex] with the item immediately above it and
     * persists both rows via [NetworkConfigRepository.updateSortOrder].
     */
    fun moveUp(index: Int) {
        if (index <= 0) return
        val currentList = services.value.toMutableList()
        val item = currentList.removeAt(index)
        currentList.add(index - 1, item)
        persistOrder(currentList)
    }

    /**
     * Moves the service at [index] one position down (away from index 0).
     */
    fun moveDown(index: Int) {
        val currentList = services.value.toMutableList()
        if (index >= currentList.lastIndex) return
        val item = currentList.removeAt(index)
        currentList.add(index + 1, item)
        persistOrder(currentList)
    }

    /**
     * Persists a full reordered list.
     * Extracts the [AppNetworkConfig] objects and delegates to the repository
     * which re-assigns [sortIndex] = position before writing to the DB.
     */
    fun persistOrder(reordered: List<ServiceManageItem>) {
        viewModelScope.launch {
            repository.updateSortOrder(reordered.map { it.config })
        }
    }
}
