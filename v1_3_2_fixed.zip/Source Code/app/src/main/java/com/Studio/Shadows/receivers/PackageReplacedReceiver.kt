package com.Studio.Shadows.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.util.Log
import com.Studio.Shadows.data.managers.UpdateManager
import java.io.File

/**
 * Fires when this app has been successfully replaced by a new version
 * (ACTION_MY_PACKAGE_REPLACED). At this point the new code is already running.
 *
 * Responsibilities:
 *   1. Delete the update APK from the private downloads directory.
 *   2. Restart the app so the user is on the new version immediately.
 *
 * This receiver runs on the main thread — keep it fast.
 */
class PackageReplacedReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        Log.i(TAG, "Package replaced — cleaning up and restarting")

        // 1. Delete both APKs (update + rollback) from the private directory.
        val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: context.filesDir

        listOf(
            UpdateManager.UPDATE_APK_NAME,
            UpdateManager.ROLLBACK_APK_NAME
        ).forEach { name ->
            val file = File(downloadsDir, name)
            if (file.exists()) {
                file.delete()
                Log.i(TAG, "Deleted: ${file.absolutePath}")
            }
        }

        // 2. Restart the app.
        val launchIntent = context.packageManager
            .getLaunchIntentForPackage(context.packageName)
            ?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }

        if (launchIntent != null) {
            context.startActivity(launchIntent)
            Log.i(TAG, "App restarted successfully")
        } else {
            Log.e(TAG, "Could not find launch intent — app will not restart automatically")
        }
    }

    companion object {
        private const val TAG = "PackageReplacedReceiver"
    }
}
