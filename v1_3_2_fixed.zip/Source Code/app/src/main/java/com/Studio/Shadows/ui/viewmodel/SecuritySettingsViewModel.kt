package com.Studio.Shadows.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.Studio.Shadows.data.model.SecurityConfig
import com.Studio.Shadows.security.BiometricStatus
import com.Studio.Shadows.security.SecurityManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SecuritySettingsViewModel @Inject constructor(
    private val securityManager: SecurityManager
) : ViewModel() {

    private val _securityConfig = MutableStateFlow<SecurityConfig?>(null)
    val securityConfig: StateFlow<SecurityConfig?> = _securityConfig

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated

    private val _biometricStatus = MutableStateFlow(BiometricStatus.UNKNOWN)
    val biometricStatus: StateFlow<BiometricStatus> = _biometricStatus

    init {
        viewModelScope.launch {
            securityManager.getSecurityConfig().collect { config ->
                _securityConfig.value = config
            }
        }
        _biometricStatus.value = securityManager.getBiometricStatus()
    }

    fun markAuthenticated() { _isAuthenticated.value = true }

    suspend fun setBiometricEnabled(enabled: Boolean) =
        securityManager.setBiometricEnabled(enabled)

    suspend fun setPinEnabled(enabled: Boolean) =
        securityManager.setPinEnabled(enabled)

    suspend fun setGlobalLockEnabled(enabled: Boolean) =
        securityManager.setGlobalLockEnabled(enabled)

    suspend fun setSecuritySettingsLockEnabled(enabled: Boolean) =
        securityManager.setSecuritySettingsLockEnabled(enabled)

    suspend fun setStealthModeEnabled(enabled: Boolean) =
        securityManager.setStealthModeEnabled(enabled)

    suspend fun setKillSwitchEnabled(enabled: Boolean) =
        securityManager.setKillSwitchEnabled(enabled)

    suspend fun setAutoLockEnabled(enabled: Boolean) =
        securityManager.setAutoLockEnabled(enabled)

    suspend fun setSessionTimeout(minutes: Int) =
        securityManager.setSessionTimeout(minutes)

    suspend fun setPin(pin: String): Result<Unit> = securityManager.setPin(pin)

    suspend fun changePin(currentPin: String, newPin: String): Result<Unit> =
        securityManager.changePin(currentPin, newPin)
}

fun BiometricStatus.isAvailable(): Boolean = this == BiometricStatus.AVAILABLE
