package com.Studio.Shadows.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.Studio.Shadows.R
import com.Studio.Shadows.data.model.AppNetworkConfig
import com.Studio.Shadows.data.model.AvailableServices
import com.Studio.Shadows.data.model.ConnectionResult
import com.Studio.Shadows.ui.theme.ShadowBackground
import com.Studio.Shadows.ui.theme.ShadowError
import com.Studio.Shadows.ui.theme.ShadowPrimary
import com.Studio.Shadows.ui.theme.ShadowSuccess
import com.Studio.Shadows.ui.theme.ShadowSurface
import com.Studio.Shadows.ui.viewmodel.NetworkSettingsViewModel
import kotlinx.coroutines.launch

/**
 * Network Settings Screen.
 *
 * Layout:
 *   1. Global IP / Backup IP fields  (always visible, above all sections)
 *   2. ── "Apps" expandable section ──
 *   3. ── "Services" expandable section ──
 *   4. Save button
 */
@Composable
fun NetworkSettingsScreen(
    snackbarHostState: SnackbarHostState,
    viewModel: NetworkSettingsViewModel = hiltViewModel()
) {
    val globalConfig  by viewModel.globalConfig.collectAsState()
    val appConfigs    by viewModel.appConfigs.collectAsState()
    val serviceConfigs by viewModel.serviceConfigs.collectAsState()
    val isSaving      by viewModel.isSaving.collectAsState()
    val saveResult    by viewModel.saveResult.collectAsState()

    val scope       = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var primaryHost by remember(globalConfig) { mutableStateOf(globalConfig?.primaryHost ?: "") }
    var backupHost  by remember(globalConfig) { mutableStateOf(globalConfig?.backupHost  ?: "") }

    LaunchedEffect(saveResult) {
        saveResult?.let { success ->
            snackbarHostState.showSnackbar(
                if (success) "Configuration saved successfully" else "Failed to save configuration"
            )
            viewModel.clearSaveResult()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ShadowBackground)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // ── Global host fields (always visible, outside the dropdowns) ────────
        Text(
            text = stringResource(R.string.network_global_settings),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = primaryHost,
            onValueChange = { primaryHost = it },
            label = { Text(stringResource(R.string.network_primary_host)) },
            placeholder = { Text(stringResource(R.string.network_primary_hint)) },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Next
            ),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ShadowPrimary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = backupHost,
            onValueChange = { backupHost = it },
            label = { Text(stringResource(R.string.network_backup_host)) },
            placeholder = { Text(stringResource(R.string.network_backup_hint)) },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Done
            ),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ShadowPrimary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(modifier = Modifier.height(24.dp))

        // ── Apps expandable section ───────────────────────────────────────────
        ConfigSection(
            title = stringResource(R.string.network_section_apps),
            icon = Icons.Default.Apps,
            itemCount = appConfigs.size,
            initiallyExpanded = true
        ) {
            appConfigs.forEach { config ->
                AppConfigItem(
                    config = config,
                    onProtocolChange = { viewModel.updateAppProtocol(config.appId, it) },
                    onPortChange     = { viewModel.updateAppPort(config.appId, it) },
                    onTestConnection = { onResult ->
                        scope.launch { onResult(viewModel.testConnection(config.appId)) }
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ── Services expandable section ───────────────────────────────────────
        ConfigSection(
            title = stringResource(R.string.network_section_services),
            icon = Icons.Default.Settings,
            itemCount = serviceConfigs.size,
            initiallyExpanded = false
        ) {
            serviceConfigs.forEach { config ->
                AppConfigItem(
                    config = config,
                    onProtocolChange = { viewModel.updateAppProtocol(config.appId, it) },
                    onPortChange     = { viewModel.updateAppPort(config.appId, it) },
                    onTestConnection = { onResult ->
                        scope.launch { onResult(viewModel.testConnection(config.appId)) }
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // ── Save button ───────────────────────────────────────────────────────
        Button(
            onClick = {
                viewModel.saveConfiguration(
                    primaryHost = primaryHost,
                    backupHost  = backupHost
                )
            },
            enabled = !isSaving,
            colors = ButtonDefaults.buttonColors(containerColor = ShadowPrimary),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (isSaving) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.dp
                )
            } else {
                Text(stringResource(R.string.network_save_config))
            }
        }

        Spacer(modifier = Modifier.height(80.dp))
    }
}

// ── Expandable section component ─────────────────────────────────────────────

@Composable
private fun ConfigSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    itemCount: Int,
    initiallyExpanded: Boolean = true,
    content: @Composable () -> Unit
) {
    var expanded by rememberSaveable { mutableStateOf(initiallyExpanded) }
    val arrowRotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(250),
        label = "section_arrow"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(ShadowSurface)
                .clickable { expanded = !expanded }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = ShadowPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "$title  ($itemCount)",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = if (expanded) "Collapse $title" else "Expand $title",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .size(22.dp)
                    .rotate(arrowRotation)
            )
        }

        // Animated content
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(animationSpec = tween(250)),
            exit  = shrinkVertically(animationSpec = tween(200))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                content()
            }
        }
    }
}

// ── Per-app config card ───────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppConfigItem(
    config: AppNetworkConfig,
    onProtocolChange: (String) -> Unit,
    onPortChange: (Int) -> Unit,
    onTestConnection: ((ConnectionResult) -> Unit) -> Unit
) {
    val service     = AvailableServices.getServiceById(config.appId)
    val serviceName = service?.let { stringResource(it.nameResId) } ?: config.appId

    // Port hint: service-specific hint, or fall back to generic "8080"
    val portHint    = service?.portHint?.takeIf { it.isNotEmpty() }
        ?: stringResource(R.string.network_port_hint)

    var protocolExpanded by remember { mutableStateOf(false) }
    var portText by remember(config.port) {
        mutableStateOf(if (config.port == 0) "" else config.port.toString())
    }
    var testResult by remember { mutableStateOf<ConnectionResult?>(null) }
    var isTesting  by remember { mutableStateOf(false) }

    val protocols = listOf("HTTP", "HTTPS")

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ShadowSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = serviceName,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Protocol dropdown
                ExposedDropdownMenuBox(
                    expanded = protocolExpanded,
                    onExpandedChange = { protocolExpanded = it },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = config.protocol,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(stringResource(R.string.network_protocol)) },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = protocolExpanded)
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ShadowPrimary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier.menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = protocolExpanded,
                        onDismissRequest = { protocolExpanded = false }
                    ) {
                        protocols.forEach { protocol ->
                            DropdownMenuItem(
                                text = { Text(protocol) },
                                onClick = {
                                    onProtocolChange(protocol)
                                    protocolExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Port field with service-specific hint
                OutlinedTextField(
                    value = portText,
                    onValueChange = { newValue ->
                        if (newValue.isEmpty() ||
                            (newValue.all { it.isDigit() } && newValue.length <= 5)
                        ) {
                            portText = newValue
                            newValue.toIntOrNull()?.let { onPortChange(it) }
                        }
                    },
                    label = { Text(stringResource(R.string.network_port)) },
                    placeholder = { Text(portHint) },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ShadowPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier.width(110.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Test connection button
                IconButton(
                    onClick = {
                        isTesting = true
                        testResult = null
                        onTestConnection { result ->
                            testResult = result
                            isTesting = false
                        }
                    },
                    enabled = !isTesting
                ) {
                    when {
                        isTesting ->
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                        testResult is ConnectionResult.Success ->
                            Icon(Icons.Default.Check, "Success", tint = ShadowSuccess)
                        testResult is ConnectionResult.Error ->
                            Icon(Icons.Default.Clear, "Failed",  tint = ShadowError)
                        else ->
                            Icon(Icons.Default.Refresh, "Test Connection")
                    }
                }
            }
        }
    }
}
