package com.Studio.Shadows.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.Studio.Shadows.data.model.AppNetworkConfig
import com.Studio.Shadows.data.repository.NetworkConfigRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

/**
 * Provides the App Drawer with visible, sorted App-type entries only.
 *
 * Service-type entries (Beszel Agent, Cloudflared, etc.) are not shown in
 * the Drawer — they are accessed from the Services screen instead.
 */
@HiltViewModel
class DrawerViewModel @Inject constructor(
    repository: NetworkConfigRepository
) : ViewModel() {

    val visibleServices: StateFlow<List<AppNetworkConfig>> = repository
        .getVisibleAppsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )
}
