package com.Studio.Shadows.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * DataStore-backed preferences for the auto-update feature.
 *
 * Keys:
 *   AUTO_UPDATE_ENABLED — whether the scheduled auto-update is active
 *   SCHEDULED_HOUR      — hour of day (0–23) for the scheduled install
 *   SCHEDULED_MINUTE    — minute (0–59) for the scheduled install
 */
private val Context.updateDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "shadow_update_prefs"
)

class UpdatePreferences(private val context: Context) {

    companion object {
        val AUTO_UPDATE_ENABLED = booleanPreferencesKey("auto_update_enabled")
        val SCHEDULED_HOUR      = intPreferencesKey("scheduled_hour")
        val SCHEDULED_MINUTE    = intPreferencesKey("scheduled_minute")

        // Sensible defaults — auto-update off, scheduled for 03:00
        const val DEFAULT_HOUR   = 3
        const val DEFAULT_MINUTE = 0
    }

    val autoUpdateEnabled: Flow<Boolean> = context.updateDataStore.data
        .map { prefs -> prefs[AUTO_UPDATE_ENABLED] ?: false }

    val scheduledHour: Flow<Int> = context.updateDataStore.data
        .map { prefs -> prefs[SCHEDULED_HOUR] ?: DEFAULT_HOUR }

    val scheduledMinute: Flow<Int> = context.updateDataStore.data
        .map { prefs -> prefs[SCHEDULED_MINUTE] ?: DEFAULT_MINUTE }

    suspend fun setAutoUpdateEnabled(enabled: Boolean) {
        context.updateDataStore.edit { prefs ->
            prefs[AUTO_UPDATE_ENABLED] = enabled
        }
    }

    suspend fun setScheduledTime(hour: Int, minute: Int) {
        context.updateDataStore.edit { prefs ->
            prefs[SCHEDULED_HOUR]   = hour.coerceIn(0, 23)
            prefs[SCHEDULED_MINUTE] = minute.coerceIn(0, 59)
        }
    }
}
