package com.Studio.Shadows.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import com.Studio.Shadows.R
import com.Studio.Shadows.data.model.AuthResult
import com.Studio.Shadows.security.BiometricStatus
import com.Studio.Shadows.security.SecurityManager
import com.Studio.Shadows.ui.theme.ShadowBackground
import com.Studio.Shadows.ui.theme.ShadowPrimary
import com.Studio.Shadows.ui.theme.ShadowSurface
import com.Studio.Shadows.ui.viewmodel.SecuritySettingsViewModel
import com.Studio.Shadows.ui.viewmodel.isAvailable
import kotlinx.coroutines.launch

/**
 * Security Settings Screen.
 *
 * Lock model implemented here:
 *
 *   Entry Methods   — Biometric switch, PIN/Device-Credential switch.
 *                     Selecting an entry method does NOT lock anything on its own.
 *
 *   Lock Switches   — "Security Settings Lock" and "Global App Lock".
 *                     Both are disabled (greyed out) unless at least one entry
 *                     method is on, so the user can never accidentally lock
 *                     themselves out without a way back in.
 *
 * Authentication to access this screen (when Security Settings Lock is ON) is
 * handled entirely by the native Android Device Credential prompt — no custom
 * in-app PIN entry UI.
 */
@Composable
fun SecuritySettingsScreen(
    securityManager: SecurityManager,
    onLockRequested: () -> Unit,
    snackbarHostState: SnackbarHostState,
    viewModel: SecuritySettingsViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    val securityConfig by viewModel.securityConfig.collectAsState()
    val isAuthenticated by viewModel.isAuthenticated.collectAsState()
    val biometricStatus by viewModel.biometricStatus.collectAsState()

    // Gate access when Security Settings Lock is active and an entry method exists.
    val settingsLocked = securityConfig?.securitySettingsLockEnabled == true &&
            (securityConfig?.biometricEnabled == true || securityConfig?.pinEnabled == true)

    // Show the system credential prompt when the screen is opened while locked.
    LaunchedEffect(isAuthenticated, settingsLocked) {
        if (!isAuthenticated && settingsLocked) {
            securityManager.authenticateWithDeviceCredential(
                activity = context as FragmentActivity,
                onResult = { result ->
                    if (result is AuthResult.Success) {
                        scope.launch { securityManager.recordAuthentication() }
                        viewModel.markAuthenticated()
                    }
                    // Cancelled / error: screen stays locked, button available to retry.
                }
            )
        }
    }

    // ── Locked state ──────────────────────────────────────────────────────────
    if (!isAuthenticated && settingsLocked) {
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.fillMaxSize().background(ShadowBackground),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                    tint = ShadowPrimary
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = stringResource(R.string.auth_required_for_security),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = {
                        securityManager.authenticateWithDeviceCredential(
                            activity = context as FragmentActivity,
                            onResult = { result ->
                                if (result is AuthResult.Success) {
                                    scope.launch { securityManager.recordAuthentication() }
                                    viewModel.markAuthenticated()
                                }
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ShadowPrimary)
                ) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Authenticate")
                }
            }
        }
        return
    }

    // ── Unlocked: full settings content ───────────────────────────────────────
    val hasAuthMethod = securityConfig?.biometricEnabled == true ||
            securityConfig?.pinEnabled == true

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ShadowBackground)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {

        // ── Section: Authentication Methods ──────────────────────────────────
        Text(
            text = "Authentication Methods",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "Select which methods are available when a lock is triggered.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Biometric entry method
        SecurityToggleItem(
            icon = Icons.Default.Fingerprint,
            title = stringResource(R.string.security_biometric_enable),
            description = when (biometricStatus) {
                BiometricStatus.AVAILABLE -> "Biometric available — tap to enable as entry method"
                BiometricStatus.NOT_ENROLLED -> "No fingerprint enrolled — add one in System Settings › Biometrics"
                BiometricStatus.NO_HARDWARE -> "This device has no biometric hardware"
                BiometricStatus.HARDWARE_UNAVAILABLE -> "Biometric hardware temporarily unavailable"
                BiometricStatus.SECURITY_UPDATE_REQUIRED -> "A security update is required before biometrics can be used"
                else -> stringResource(R.string.security_biometric_desc)
            },
            checked = securityConfig?.biometricEnabled ?: false,
            enabled = biometricStatus.isAvailable(),
            onCheckedChange = { enabled ->
                scope.launch {
                    viewModel.setBiometricEnabled(enabled)
                    // If disabling biometric removes the last entry method, auto-disable locks.
                    if (!enabled) {
                        val pinStillOn = securityConfig?.pinEnabled == true
                        if (!pinStillOn) {
                            viewModel.setGlobalLockEnabled(false)
                            viewModel.setSecuritySettingsLockEnabled(false)
                        }
                    }
                    snackbarHostState.showSnackbar(
                        if (enabled) "Biometric enabled as entry method"
                        else "Biometric disabled"
                    )
                }
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // PIN / Device-credential entry method
        SecurityToggleItem(
            icon = Icons.Default.Password,
            title = stringResource(R.string.security_pin_enable),
            description = "Uses your device PIN, pattern, or password as a backup entry method",
            checked = securityConfig?.pinEnabled ?: false,
            onCheckedChange = { enabled ->
                scope.launch {
                    viewModel.setPinEnabled(enabled)
                    // If disabling PIN removes the last entry method, auto-disable locks.
                    if (!enabled) {
                        val biometricStillOn = securityConfig?.biometricEnabled == true
                        if (!biometricStillOn) {
                            viewModel.setGlobalLockEnabled(false)
                            viewModel.setSecuritySettingsLockEnabled(false)
                        }
                    }
                    snackbarHostState.showSnackbar(
                        if (enabled) "Device PIN/credential enabled as entry method"
                        else "Device PIN/credential disabled"
                    )
                }
            }
        )

        Spacer(modifier = Modifier.height(24.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(modifier = Modifier.height(24.dp))

        // ── Section: Lock Conditions ──────────────────────────────────────────
        Text(
            text = "Lock Conditions",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = if (hasAuthMethod)
                "Choose where authentication is required."
            else
                "Enable at least one entry method above to activate locks.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Security Settings Lock
        SecurityToggleItem(
            icon = Icons.Default.Shield,
            title = "Security Settings Lock",
            description = if (hasAuthMethod)
                "Require authentication to open this settings screen"
            else
                "Enable an entry method first",
            checked = securityConfig?.securitySettingsLockEnabled ?: false,
            enabled = hasAuthMethod,
            onCheckedChange = { enabled ->
                scope.launch {
                    viewModel.setSecuritySettingsLockEnabled(enabled)
                    snackbarHostState.showSnackbar(
                        if (enabled) "Security settings lock enabled"
                        else "Security settings lock disabled"
                    )
                }
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Global App Lock
        SecurityToggleItem(
            icon = Icons.Default.Lock,
            title = "Global App Lock",
            description = if (hasAuthMethod)
                "Require authentication every time the app is opened"
            else
                "Enable an entry method first",
            checked = securityConfig?.globalLockEnabled ?: false,
            enabled = hasAuthMethod,
            onCheckedChange = { enabled ->
                scope.launch {
                    viewModel.setGlobalLockEnabled(enabled)
                    snackbarHostState.showSnackbar(
                        if (enabled) "Global app lock enabled"
                        else "Global app lock disabled"
                    )
                }
            }
        )

        Spacer(modifier = Modifier.height(24.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(modifier = Modifier.height(24.dp))

        // ── Section: Security Features ────────────────────────────────────────
        Text(
            text = "Security Features",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(16.dp))

        SecurityToggleItem(
            icon = Icons.Default.Security,
            title = stringResource(R.string.security_stealth_mode),
            description = stringResource(R.string.security_stealth_desc),
            checked = securityConfig?.stealthModeEnabled ?: false,
            onCheckedChange = { enabled ->
                scope.launch {
                    viewModel.setStealthModeEnabled(enabled)
                    snackbarHostState.showSnackbar(
                        if (enabled) "Stealth mode enabled" else "Stealth mode disabled"
                    )
                }
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        SecurityToggleItem(
            icon = Icons.Default.Security,
            title = stringResource(R.string.security_kill_switch),
            description = stringResource(R.string.security_kill_switch_desc),
            checked = securityConfig?.killSwitchEnabled ?: false,
            onCheckedChange = { enabled ->
                scope.launch {
                    viewModel.setKillSwitchEnabled(enabled)
                    snackbarHostState.showSnackbar(
                        if (enabled) "Kill switch enabled" else "Kill switch disabled"
                    )
                }
            }
        )

        Spacer(modifier = Modifier.height(80.dp))
    }
}

// ── Reusable toggle card ──────────────────────────────────────────────────────

@Composable
private fun SecurityToggleItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ShadowSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (enabled) ShadowPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (enabled) MaterialTheme.colorScheme.onBackground
                            else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                enabled = enabled,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = ShadowPrimary,
                    checkedTrackColor = ShadowPrimary.copy(alpha = 0.5f)
                )
            )
        }
    }
}
