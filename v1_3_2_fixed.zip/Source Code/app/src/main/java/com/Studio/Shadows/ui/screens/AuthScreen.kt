package com.Studio.Shadows.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.Studio.Shadows.R
import com.Studio.Shadows.data.model.AuthResult
import com.Studio.Shadows.data.model.SessionState
import com.Studio.Shadows.security.SecurityManager
import com.Studio.Shadows.data.model.requiresAuthentication
import com.Studio.Shadows.ui.theme.ShadowBackground
import com.Studio.Shadows.ui.theme.ShadowError
import com.Studio.Shadows.ui.theme.ShadowPrimary
import kotlinx.coroutines.launch

/**
 * Authentication Screen
 *
 * [FIX 2] The custom in-app PIN entry (hash-based) has been removed.
 * Authentication is now fully delegated to the native Android Device Credentials
 * system via SecurityManager.authenticateWithDeviceCredential(), which presents
 * the standard system prompt and supports biometric + PIN/pattern/password in
 * a single flow without any custom UI.
 */
@Composable
fun AuthScreen(
    securityManager: SecurityManager,
    onAuthenticated: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val securityConfig by securityManager.getSecurityConfig().collectAsState(initial = null)

    var isLoading by remember { mutableStateOf(true) }
    var sessionState by remember { mutableStateOf<SessionState>(SessionState.Unauthenticated) }
    // Prevent the system prompt from being launched more than once automatically.
    var promptLaunched by remember { mutableStateOf(false) }

    /**
     * Helper that delegates to the single native credential prompt.
     * On success: records the authentication timestamp and unlocks the app.
     * On failure/cancel: stays on AuthScreen so the user can retry via the button.
     */
    fun launchCredentialPrompt() {
        securityManager.authenticateWithDeviceCredential(
            activity = context as FragmentActivity,
            onResult = { result ->
                when (result) {
                    is AuthResult.Success -> {
                        scope.launch { securityManager.recordAuthentication() }
                        onAuthenticated()
                    }
                    // Canceled or error: stay on screen, user can tap button to retry.
                    else -> { /* no-op */ }
                }
            }
        )
    }

    // Auto-launch the native credential prompt once we know auth is required.
    LaunchedEffect(securityConfig) {
        val config = securityConfig ?: return@LaunchedEffect
        sessionState = securityManager.getSessionState()
        isLoading = false

        when {
            !config.requiresAuthentication() -> {
                // No auth method configured — auto-unlock immediately.
                onAuthenticated()
            }
            !promptLaunched -> {
                promptLaunched = true
                launchCredentialPrompt()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ShadowBackground),
        contentAlignment = Alignment.Center
    ) {
        when {
            isLoading -> {
                CircularProgressIndicator(color = ShadowPrimary)
            }

            sessionState is SessionState.LockedOut -> {
                val remainingMinutes = (sessionState as SessionState.LockedOut).remainingMinutes
                LockedOutView(remainingMinutes = remainingMinutes)
            }

            else -> {
                // Show a prompt for the user to (re-)trigger authentication after a cancel.
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(80.dp),
                        tint = ShadowPrimary
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = stringResource(R.string.auth_title),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Use your device credentials to unlock",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    Button(
                        onClick = { launchCredentialPrompt() },
                        colors = ButtonDefaults.buttonColors(containerColor = ShadowPrimary),
                        modifier = Modifier.fillMaxWidth(0.7f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.auth_biometric_prompt))
                    }
                }
            }
        }
    }
}

@Composable
private fun LockedOutView(remainingMinutes: Int) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.padding(32.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = null,
            modifier = Modifier.size(80.dp),
            tint = ShadowError
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Account Locked",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Too many failed attempts. Please wait $remainingMinutes minutes.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}
