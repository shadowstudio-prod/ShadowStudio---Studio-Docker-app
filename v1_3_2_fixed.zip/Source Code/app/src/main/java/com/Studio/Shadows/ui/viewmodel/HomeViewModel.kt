package com.Studio.Shadows.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.Studio.Shadows.data.model.AppModel
import com.Studio.Shadows.data.model.AppStatus
import com.Studio.Shadows.data.model.AvailableServices
import com.Studio.Shadows.data.model.ConnectionResult
import com.Studio.Shadows.data.repository.NetworkConfigRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Home screen dashboard.
 *
 * [services] is driven by [getVisibleAppsFlow] — only App-type entries appear
 * on the Home screen. Service-type entries (Beszel Agent, Cloudflared, etc.)
 * are shown on the dedicated Services screen instead.
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: NetworkConfigRepository
) : ViewModel() {

    val services: StateFlow<List<AppModel>> = repository
        .getVisibleAppsFlow()
        .map { configs ->
            configs.mapNotNull { config ->
                AvailableServices.getServiceById(config.appId)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    private val _serviceStatuses = MutableStateFlow<Map<String, AppStatus>>(emptyMap())
    val serviceStatuses: StateFlow<Map<String, AppStatus>> = _serviceStatuses.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    init {
        viewModelScope.launch {
            services.collect { serviceList ->
                if (serviceList.isNotEmpty() && _serviceStatuses.value.isEmpty()) {
                    refreshStatuses()
                }
            }
        }
    }

    fun refreshStatuses() {
        viewModelScope.launch {
            _isRefreshing.value = true
            val currentServices = services.value
            val results = currentServices.map { appModel ->
                async {
                    val startTime = System.currentTimeMillis()
                    val serviceUrl = repository.buildServiceUrlWithFailover(appModel.id)
                    if (!serviceUrl.isValid || serviceUrl.url.isBlank()) {
                        return@async appModel.id to AppStatus(
                            appId = appModel.id,
                            isOnline = false,
                            lastChecked = System.currentTimeMillis(),
                            errorMessage = "No URL configured"
                        )
                    }
                    val result = repository.testConnection(serviceUrl.url)
                    val responseTime = System.currentTimeMillis() - startTime
                    appModel.id to AppStatus(
                        appId = appModel.id,
                        isOnline = result is ConnectionResult.Success,
                        lastChecked = System.currentTimeMillis(),
                        responseTimeMs = responseTime
                    )
                }
            }.awaitAll()

            _serviceStatuses.value = results.toMap()
            _isRefreshing.value = false
        }
    }
}
