package com.Studio.Shadows.data.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.Studio.Shadows.R

/**
 * Data class representing a service/application in ShadowStudio.
 *
 * [NEW] isService     — true = item belongs to the Services screen, false = Apps screen.
 * [NEW] portHint      — shown as placeholder text in the Network Settings port field
 *                       when no port is configured (port == 0).
 * [NEW] openInWebView — for Services only: true means the card is tappable and opens
 *                       a WebView (VaultWarden, Pi-Hole). false = status-only.
 *                       Apps always open in a WebView regardless of this flag.
 */
data class AppModel(
    val id: String,
    @StringRes val nameResId: Int,
    @StringRes val descriptionResId: Int,
    @DrawableRes val iconResId: Int,
    val defaultPort: Int,
    val isOnline: Boolean = false,
    val supportsHttps: Boolean = true,
    val category: AppCategory = AppCategory.MEDIA,
    val order: Int = 0,
    val isEnabled: Boolean = true,
    // ── v2.0 ─────────────────────────────────────────────────────────────────
    val isService: Boolean = false,
    val portHint: String = "",
    val openInWebView: Boolean = true
)

/**
 * Categories for organising apps (unchanged)
 */
enum class AppCategory {
    MEDIA,
    STORAGE,
    SECURITY,
    AUTOMATION,
    NETWORK,
    MONITORING,
    DEVELOPMENT
}

/**
 * Protocol options for service connections
 */
enum class ConnectionProtocol {
    HTTP,
    HTTPS
}

/**
 * Object containing all available apps and services in ShadowStudio.
 *
 * ── Apps ─────────────────────────────────────────────────────────────────────
 * These open in a WebView and appear on the Home screen and App Drawer.
 *
 * ── Services ─────────────────────────────────────────────────────────────────
 * These appear on the Services screen. Most are status-only; VaultWarden and
 * Pi-Hole have openInWebView = true so they can be opened in a WebView.
 */
object AvailableServices {

    // ── Apps ──────────────────────────────────────────────────────────────────

    val BESZEL = AppModel(
        id = "beszel",
        nameResId = R.string.app_name_beszel,
        descriptionResId = R.string.service_beszel,
        iconResId = R.drawable.ic_beszel,
        defaultPort = 0,
        portHint = "8090",
        supportsHttps = false,
        category = AppCategory.MONITORING,
        isService = false
    )

    val CRAFTY4 = AppModel(
        id = "crafty4",
        nameResId = R.string.app_name_crafty4,
        descriptionResId = R.string.service_crafty4,
        iconResId = R.drawable.ic_crafty4,
        defaultPort = 0,
        portHint = "8443",
        supportsHttps = true,
        category = AppCategory.DEVELOPMENT,
        isService = false
    )

    val HOMEASSISTANT = AppModel(
        id = "homeassistant",
        nameResId = R.string.app_name_homeassistant,
        descriptionResId = R.string.service_homeassistant,
        iconResId = R.drawable.ic_homeassistant,
        defaultPort = 0,
        portHint = "8123",
        supportsHttps = true,
        category = AppCategory.AUTOMATION,
        isService = false
    )

    val HOMEPAGE = AppModel(
        id = "homepage",
        nameResId = R.string.app_name_homepage,
        descriptionResId = R.string.service_homepage,
        iconResId = R.drawable.ic_homepage,
        defaultPort = 0,
        portHint = "3000",
        supportsHttps = true,
        category = AppCategory.MONITORING,
        isService = false
    )

    val IMMICH = AppModel(
        id = "immich",
        nameResId = R.string.app_name_immich,
        descriptionResId = R.string.service_immich,
        iconResId = R.drawable.ic_immich,
        defaultPort = 0,
        portHint = "2283",
        supportsHttps = true,
        category = AppCategory.MEDIA,
        isService = false
    )

    val JELLYFIN = AppModel(
        id = "jellyfin",
        nameResId = R.string.app_name_jellyfin,
        descriptionResId = R.string.service_jellyfin,
        iconResId = R.drawable.ic_jellyfin,
        defaultPort = 0,
        portHint = "8096",
        supportsHttps = true,
        category = AppCategory.MEDIA,
        isService = false
    )

    val WEBUI = AppModel(
        id = "webui",
        nameResId = R.string.app_name_webui,
        descriptionResId = R.string.service_webui,
        iconResId = R.drawable.ic_webui,
        defaultPort = 0,
        portHint = "3000",
        supportsHttps = true,
        category = AppCategory.DEVELOPMENT,
        isService = false
    )

    val N8N = AppModel(
        id = "n8n",
        nameResId = R.string.app_name_n8n,
        descriptionResId = R.string.service_n8n,
        iconResId = R.drawable.ic_n8n,
        defaultPort = 0,
        portHint = "5678",
        supportsHttps = true,
        category = AppCategory.AUTOMATION,
        isService = false
    )

    val NGINX = AppModel(
        id = "nginx",
        nameResId = R.string.app_name_nginx,
        descriptionResId = R.string.service_nginx,
        iconResId = R.drawable.ic_nginx,
        defaultPort = 0,
        portHint = "81",
        supportsHttps = true,
        category = AppCategory.NETWORK,
        isService = false
    )

    val TRACCAR = AppModel(
        id = "traccar",
        nameResId = R.string.app_name_traccar,
        descriptionResId = R.string.service_traccar,
        iconResId = R.drawable.ic_traccar,
        defaultPort = 0,
        portHint = "8082",
        supportsHttps = true,
        category = AppCategory.MONITORING,
        isService = false
    )

    // ── Services ──────────────────────────────────────────────────────────────

    val BESZEL_AGENT = AppModel(
        id = "beszel-agent",
        nameResId = R.string.app_name_beszel_agent,
        descriptionResId = R.string.service_beszel_agent,
        iconResId = R.drawable.ic_beszel_agent,
        defaultPort = 0,
        portHint = "45876",
        supportsHttps = false,
        category = AppCategory.MONITORING,
        isService = true,
        openInWebView = false
    )

    val CLOUDFLARED = AppModel(
        id = "cloudflared",
        nameResId = R.string.app_name_cloudflared,
        descriptionResId = R.string.service_cloudflared,
        iconResId = R.drawable.ic_cloudflared,
        defaultPort = 0,
        portHint = "14333",
        supportsHttps = false,
        category = AppCategory.NETWORK,
        isService = true,
        openInWebView = false
    )

    val OLLAMA = AppModel(
        id = "ollama",
        nameResId = R.string.app_name_ollama,
        descriptionResId = R.string.service_ollama,
        iconResId = R.drawable.ic_ollama,
        defaultPort = 0,
        portHint = "11434",
        supportsHttps = false,
        category = AppCategory.DEVELOPMENT,
        isService = true,
        openInWebView = false
    )

    val SSUPDATER = AppModel(
        id = "ssupdater",
        nameResId = R.string.app_name_ssupdater,
        descriptionResId = R.string.service_ssupdater,
        iconResId = R.drawable.ic_ssupdater,
        defaultPort = 0,
        portHint = "8080",
        supportsHttps = false,
        category = AppCategory.NETWORK,
        isService = true,
        openInWebView = false
    )

    val TAILSCALE = AppModel(
        id = "tailscale",
        nameResId = R.string.app_name_tailscale,
        descriptionResId = R.string.service_tailscale,
        iconResId = R.drawable.ic_tailscale,
        defaultPort = 0,
        portHint = "41641",
        supportsHttps = false,
        category = AppCategory.NETWORK,
        isService = true,
        openInWebView = false
    )

    val TALK_AIO = AppModel(
        id = "talk-aio",
        nameResId = R.string.app_name_talk_aio,
        descriptionResId = R.string.service_talk_aio,
        iconResId = R.drawable.ic_nextcloud,
        defaultPort = 0,
        portHint = "8880",
        supportsHttps = true,
        category = AppCategory.STORAGE,
        isService = true,
        openInWebView = false
    )

    val PIHOLE = AppModel(
        id = "pihole",
        nameResId = R.string.app_name_pihole,
        descriptionResId = R.string.service_pihole,
        iconResId = R.drawable.ic_pihole,
        defaultPort = 0,
        portHint = "80",
        supportsHttps = false,
        category = AppCategory.NETWORK,
        isService = true,
        openInWebView = true   // Has a GUI — tappable on Services screen
    )

    val VAULTWARDEN = AppModel(
        id = "vaultwarden",
        nameResId = R.string.app_name_vaultwarden,
        descriptionResId = R.string.service_vaultwarden,
        iconResId = R.drawable.ic_bitwarden,
        defaultPort = 0,
        portHint = "80",
        supportsHttps = true,
        category = AppCategory.SECURITY,
        isService = true,
        openInWebView = true   // Has a GUI — tappable on Services screen
    )

    // ── Kept from previous version (not in current list but preserved) ────────

    val RIPPER = AppModel(
        id = "ripper",
        nameResId = R.string.app_name_ripper,
        descriptionResId = R.string.service_ripper,
        iconResId = R.drawable.ic_ripper,
        defaultPort = 0,
        portHint = "8080",
        supportsHttps = false,
        category = AppCategory.MEDIA,
        isService = false
    )

    val ROMM = AppModel(
        id = "romm",
        nameResId = R.string.app_name_romm,
        descriptionResId = R.string.service_romm,
        iconResId = R.drawable.ic_romm,
        defaultPort = 0,
        portHint = "8061",
        supportsHttps = true,
        category = AppCategory.MEDIA,
        isService = false
    )

    // ── Lookup & grouping ─────────────────────────────────────────────────────

    /** All entries — Apps + Services + legacy. Used by ManageServices and DB seeding. */
    fun getAllServices(): List<AppModel> = listOf(
        // Apps
        BESZEL, CRAFTY4, HOMEASSISTANT, HOMEPAGE, IMMICH,
        JELLYFIN, WEBUI, N8N, NGINX, TRACCAR,
        // Services
        BESZEL_AGENT, CLOUDFLARED, OLLAMA, SSUPDATER,
        TAILSCALE, TALK_AIO, PIHOLE, VAULTWARDEN,
        // Legacy (preserved)
        RIPPER, ROMM
    )

    /** Only App-type entries. Used by HomeViewModel and DrawerViewModel. */
    fun getAllApps(): List<AppModel> = getAllServices().filter { !it.isService }

    /** Only Service-type entries. Used by ServicesViewModel. */
    fun getAllServiceItems(): List<AppModel> = getAllServices().filter { it.isService }

    /** Look up any entry by id. */
    fun getServiceById(id: String): AppModel? = getAllServices().find { it.id == id }

    fun getServicesByCategory(): Map<AppCategory, List<AppModel>> =
        getAllServices().groupBy { it.category }
}

data class AppConfiguration(
    val appId: String,
    val protocol: ConnectionProtocol = ConnectionProtocol.HTTP,
    val port: Int,
    val isEnabled: Boolean = true,
    val customPath: String = ""
)

data class AppStatus(
    val appId: String,
    val isOnline: Boolean = false,
    val lastChecked: Long = 0,
    val responseTimeMs: Long = 0,
    val errorMessage: String? = null
)
