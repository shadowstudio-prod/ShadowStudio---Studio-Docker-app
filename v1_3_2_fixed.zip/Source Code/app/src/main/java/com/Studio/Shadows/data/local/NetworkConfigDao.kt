package com.Studio.Shadows.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.Studio.Shadows.data.model.AppNetworkConfig
import com.Studio.Shadows.data.model.GlobalNetworkConfig
import kotlinx.coroutines.flow.Flow

@Dao
interface NetworkConfigDao {

    // ==================== Global Config ====================

    @Query("SELECT * FROM network_config WHERE id = 1")
    fun getGlobalConfigFlow(): Flow<GlobalNetworkConfig?>

    @Query("SELECT * FROM network_config WHERE id = 1")
    suspend fun getGlobalConfig(): GlobalNetworkConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGlobalConfig(config: GlobalNetworkConfig)

    @Update
    suspend fun updateGlobalConfig(config: GlobalNetworkConfig)

    @Query("UPDATE network_config SET primaryHost = :host, lastUpdated = :timestamp WHERE id = 1")
    suspend fun updatePrimaryHost(host: String, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE network_config SET backupHost = :host, lastUpdated = :timestamp WHERE id = 1")
    suspend fun updateBackupHost(host: String, timestamp: Long = System.currentTimeMillis())

    // ==================== App Config — All (Manage Services) ====================

    @Query("SELECT * FROM app_network_config ORDER BY sortIndex ASC")
    fun getAllAppConfigsFlow(): Flow<List<AppNetworkConfig>>

    @Query("SELECT * FROM app_network_config ORDER BY sortIndex ASC")
    suspend fun getAllAppConfigs(): List<AppNetworkConfig>

    // ==================== App Config — Visible, all types ====================

    /** All visible entries regardless of serviceType. */
    @Query("SELECT * FROM app_network_config WHERE isHidden = 0 ORDER BY sortIndex ASC")
    fun getVisibleAppConfigsFlow(): Flow<List<AppNetworkConfig>>

    @Query("SELECT * FROM app_network_config WHERE isHidden = 0 ORDER BY sortIndex ASC")
    suspend fun getVisibleAppConfigs(): List<AppNetworkConfig>

    // ==================== App Config — Visible, filtered by type ====================

    /**
     * Visible entries for a specific serviceType ("APP" or "SERVICE").
     * Used by HomeViewModel (APP), DrawerViewModel (APP), and ServicesViewModel (SERVICE).
     */
    @Query("SELECT * FROM app_network_config WHERE isHidden = 0 AND serviceType = :serviceType ORDER BY sortIndex ASC")
    fun getVisibleConfigsByTypeFlow(serviceType: String): Flow<List<AppNetworkConfig>>

    @Query("SELECT * FROM app_network_config WHERE isHidden = 0 AND serviceType = :serviceType ORDER BY sortIndex ASC")
    suspend fun getVisibleConfigsByType(serviceType: String): List<AppNetworkConfig>

    // ==================== Single App Config ====================

    @Query("SELECT * FROM app_network_config WHERE appId = :appId")
    suspend fun getAppConfig(appId: String): AppNetworkConfig?

    @Query("SELECT * FROM app_network_config WHERE appId = :appId")
    fun getAppConfigFlow(appId: String): Flow<AppNetworkConfig?>

    // ==================== Insert / Update ====================

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppConfig(config: AppNetworkConfig)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAppConfigs(configs: List<AppNetworkConfig>)

    @Update
    suspend fun updateAppConfig(config: AppNetworkConfig)

    @Update
    suspend fun updateAllAppConfigs(configs: List<AppNetworkConfig>)

    @Query("UPDATE app_network_config SET protocol = :protocol, port = :port, lastUpdated = :timestamp WHERE appId = :appId")
    suspend fun updateAppProtocolAndPort(
        appId: String,
        protocol: String,
        port: Int,
        timestamp: Long = System.currentTimeMillis()
    )

    @Query("UPDATE app_network_config SET isEnabled = :enabled WHERE appId = :appId")
    suspend fun setAppEnabled(appId: String, enabled: Boolean)

    @Query("UPDATE app_network_config SET isHidden = :isHidden WHERE appId = :appId")
    suspend fun setAppHidden(appId: String, isHidden: Boolean)

    @Query("UPDATE app_network_config SET sortIndex = :sortIndex WHERE appId = :appId")
    suspend fun updateSortIndex(appId: String, sortIndex: Int)

    // ==================== Delete ====================

    @Query("DELETE FROM app_network_config WHERE appId = :appId")
    suspend fun deleteAppConfig(appId: String)

    @Query("DELETE FROM app_network_config")
    suspend fun deleteAllAppConfigs()
}
