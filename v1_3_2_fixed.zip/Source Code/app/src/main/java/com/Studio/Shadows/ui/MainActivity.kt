package com.Studio.Shadows.ui

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.Studio.Shadows.R
import com.Studio.Shadows.data.model.AvailableServices
import com.Studio.Shadows.security.SecurityManager
import com.Studio.Shadows.ui.screens.AuthScreen
import com.Studio.Shadows.ui.screens.HomeScreen
import com.Studio.Shadows.ui.screens.ManageServicesScreen
import com.Studio.Shadows.ui.screens.NetworkSettingsScreen
import com.Studio.Shadows.ui.screens.SecuritySettingsScreen
import com.Studio.Shadows.ui.screens.ServiceWebViewScreen
import com.Studio.Shadows.ui.screens.ServicesScreen
import com.Studio.Shadows.ui.screens.SettingsScreen
import com.Studio.Shadows.ui.screens.UpdateScreenWrapper
import com.Studio.Shadows.ui.theme.ShadowBackground
import com.Studio.Shadows.ui.theme.ShadowStudioTheme
import com.Studio.Shadows.ui.theme.ShadowSurface
import com.Studio.Shadows.ui.theme.getServiceColor
import com.Studio.Shadows.ui.viewmodel.DrawerViewModel
import com.Studio.Shadows.ui.viewmodel.MainViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── Navigation routes ─────────────────────────────────────────────────────────

sealed class Screen(val route: String, val titleResId: Int, val icon: ImageVector? = null) {
    object Auth            : Screen("auth",             R.string.auth_title)
    object Home            : Screen("home",             R.string.home_title,     Icons.Outlined.Home)
    object Services        : Screen("services",         R.string.services_title)
    object NetworkSettings : Screen("network_settings", R.string.network_title,  Icons.Outlined.Settings)
    object SecuritySettings: Screen("security_settings",R.string.security_title, Icons.Outlined.Security)
    object Settings        : Screen("settings",         R.string.settings_title, Icons.Default.Settings)
    object ManageServices  : Screen("manage_services",  R.string.manage_services_title)
    object UpdateScreen    : Screen("update_screen",    R.string.update_title)
    object WebView         : Screen("webview/{serviceId}", R.string.app_name)

    fun createWebViewRoute(serviceId: String) = "webview/$serviceId"
}

data class DrawerItem(
    val screen: Screen,
    val serviceId: String? = null,
    val iconResId: Int? = null
)

// ── Activity ──────────────────────────────────────────────────────────────────

@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    @Inject
    lateinit var securityManager: SecurityManager

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)

        var isReady by mutableStateOf(false)
        splashScreen.setKeepOnScreenCondition { !isReady }

        lifecycleScope.launch {
            securityManager.initializeDefaultConfig()
            viewModel.checkAuthentication()
            isReady = true
        }

        setContent {
            ShadowStudioTheme {
                val isAuthenticated by viewModel.isAuthenticated.collectAsState()
                val securityConfig by securityManager.getSecurityConfig()
                    .collectAsState(initial = null)

                LaunchedEffect(securityConfig?.stealthModeEnabled) {
                    if (securityConfig?.stealthModeEnabled == true) {
                        window.setFlags(
                            WindowManager.LayoutParams.FLAG_SECURE,
                            WindowManager.LayoutParams.FLAG_SECURE
                        )
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    }
                }

                if (securityConfig == null) {
                    Box(modifier = Modifier.fillMaxSize())
                    return@ShadowStudioTheme
                }

                if (isAuthenticated) {
                    ShadowStudioApp(
                        securityManager = securityManager,
                        onLockRequested = { viewModel.lockApp() }
                    )
                } else {
                    AuthScreen(
                        securityManager = securityManager,
                        onAuthenticated = { viewModel.authenticate() }
                    )
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        lifecycleScope.launch {
            val config = securityManager.getSecurityConfig().firstOrNull()
            if (config?.killSwitchEnabled == true) finishAndRemoveTask()
        }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            val config = securityManager.getSecurityConfig().firstOrNull() ?: return@launch
            val hasAuthMethod = config.biometricEnabled || config.pinEnabled
            if (hasAuthMethod && config.globalLockEnabled && viewModel.isAuthenticated.value) {
                if (securityManager.isAuthenticationRequired()) viewModel.lockApp()
            }
        }
    }
}

// ── App shell ─────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShadowStudioApp(
    securityManager: SecurityManager,
    onLockRequested: () -> Unit,
    drawerViewModel: DrawerViewModel = hiltViewModel()
) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStackEntry?.destination?.route ?: Screen.Home.route

    val visibleServices by drawerViewModel.visibleServices.collectAsState()

    // Drawer shows App-type entries only (Services are accessed via the Services screen).
    val drawerItems = remember(visibleServices) {
        val items = mutableListOf<DrawerItem>()
        items.add(DrawerItem(Screen.Home))
        visibleServices.forEach { config ->
            val appModel = AvailableServices.getServiceById(config.appId) ?: return@forEach
            items.add(
                DrawerItem(
                    screen = Screen.WebView,
                    serviceId = config.appId,
                    iconResId = appModel.iconResId
                )
            )
        }
        items.toList()
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = drawerState.isOpen,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = ShadowSurface) {
                Spacer(modifier = Modifier.height(120.dp))
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(drawerItems) { item ->
                        val isSelected = when (item.screen) {
                            is Screen.Home    -> currentRoute == Screen.Home.route
                            is Screen.WebView -> currentRoute.startsWith("webview") &&
                                    currentBackStackEntry?.arguments?.getString("serviceId") == item.serviceId
                            else -> false
                        }
                        val title = when (item.screen) {
                            is Screen.Home -> stringResource(R.string.nav_home)
                            else -> item.serviceId?.let {
                                AvailableServices.getServiceById(it)?.nameResId?.let { resId ->
                                    stringResource(resId)
                                }
                            } ?: ""
                        }
                        val icon: @Composable () -> Unit = item.iconResId?.let { resId ->
                            {
                                Icon(
                                    painter = painterResource(resId),
                                    contentDescription = title,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        } ?: item.screen.icon?.let { iv ->
                            { Icon(imageVector = iv, contentDescription = title) }
                        } ?: { Icon(imageVector = Icons.Outlined.Home, contentDescription = title) }

                        NavigationDrawerItem(
                            icon = icon,
                            label = { Text(title) },
                            selected = isSelected,
                            onClick = {
                                scope.launch {
                                    drawerState.close()
                                    when (item.screen) {
                                        is Screen.Home -> navController.navigate(Screen.Home.route) {
                                            popUpTo(Screen.Home.route) { inclusive = true }
                                        }
                                        is Screen.WebView -> item.serviceId?.let { serviceId ->
                                            navController.navigate(
                                                item.screen.createWebViewRoute(serviceId)
                                            )
                                        }
                                        else -> {}
                                    }
                                }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = item.serviceId?.let {
                                    getServiceColor(it).copy(alpha = 0.2f)
                                } ?: MaterialTheme.colorScheme.primaryContainer
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = stringResource(R.string.nav_settings)
                        )
                    },
                    label = { Text(stringResource(R.string.nav_settings)) },
                    selected = currentRoute == Screen.Settings.route,
                    onClick = {
                        scope.launch {
                            drawerState.close()
                            navController.navigate(Screen.Settings.route)
                        }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        val title = when {
                            currentRoute == Screen.Home.route            -> stringResource(R.string.home_title)
                            currentRoute == Screen.Services.route        -> stringResource(R.string.services_title)
                            currentRoute == Screen.NetworkSettings.route -> stringResource(R.string.network_title)
                            currentRoute == Screen.SecuritySettings.route-> stringResource(R.string.security_title)
                            currentRoute == Screen.Settings.route        -> stringResource(R.string.settings_title)
                            currentRoute == Screen.ManageServices.route  -> stringResource(R.string.manage_services_title)
                            currentRoute == Screen.UpdateScreen.route    -> stringResource(R.string.update_title)
                            currentRoute.startsWith("webview") -> {
                                val serviceId = currentBackStackEntry?.arguments?.getString("serviceId")
                                serviceId?.let {
                                    AvailableServices.getServiceById(it)?.nameResId?.let { resId ->
                                        stringResource(resId)
                                    }
                                } ?: stringResource(R.string.app_name)
                            }
                            else -> stringResource(R.string.app_name)
                        }
                        Text(title)
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = stringResource(R.string.nav_open_drawer)
                            )
                        }
                    },
                    actions = {
                        if (currentRoute == Screen.Home.route) {
                            IconButton(onClick = { navController.navigate(Screen.Settings.route) }) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = stringResource(R.string.nav_settings)
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = ShadowBackground,
                        titleContentColor = MaterialTheme.colorScheme.onBackground,
                        navigationIconContentColor = MaterialTheme.colorScheme.onBackground,
                        actionIconContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) },
            containerColor = ShadowBackground
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                NavigationGraph(
                    navController = navController,
                    securityManager = securityManager,
                    snackbarHostState = snackbarHostState,
                    onLockRequested = onLockRequested
                )
            }
        }
    }
}

// ── Navigation graph ──────────────────────────────────────────────────────────

@Composable
fun NavigationGraph(
    navController: NavHostController,
    securityManager: SecurityManager,
    snackbarHostState: SnackbarHostState,
    onLockRequested: () -> Unit
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onServiceClick = { serviceId ->
                    navController.navigate(Screen.WebView.createWebViewRoute(serviceId))
                },
                onSettingsClick = { navController.navigate(Screen.Settings.route) }
            )
        }

        // ── NEW: Services screen ───────────────────────────────────────────
        composable(Screen.Services.route) {
            ServicesScreen(
                onServiceClick = { serviceId ->
                    navController.navigate(Screen.WebView.createWebViewRoute(serviceId))
                }
            )
        }

        composable(Screen.NetworkSettings.route) {
            NetworkSettingsScreen(snackbarHostState = snackbarHostState)
        }

        composable(Screen.SecuritySettings.route) {
            SecuritySettingsScreen(
                securityManager = securityManager,
                onLockRequested = onLockRequested,
                snackbarHostState = snackbarHostState
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onNetworkSettingsClick  = { navController.navigate(Screen.NetworkSettings.route) },
                onSecuritySettingsClick = { navController.navigate(Screen.SecuritySettings.route) },
                onUpdateClick           = { navController.navigate(Screen.UpdateScreen.route) },
                onManageServicesClick   = { navController.navigate(Screen.ManageServices.route) },
                onServicesClick         = { navController.navigate(Screen.Services.route) },
                securityManager = securityManager
            )
        }

        composable(Screen.ManageServices.route) {
            ManageServicesScreen()
        }

        composable(Screen.UpdateScreen.route) {
            UpdateScreenWrapper()
        }

        composable(Screen.WebView.route) { backStackEntry ->
            val serviceId = backStackEntry.arguments?.getString("serviceId") ?: ""
            ServiceWebViewScreen(serviceId = serviceId)
        }
    }
}
