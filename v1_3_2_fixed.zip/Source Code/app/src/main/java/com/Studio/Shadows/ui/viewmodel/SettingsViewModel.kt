package com.Studio.Shadows.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.Studio.Shadows.security.EncryptedPreferenceManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for Settings Screen.
 * Update logic has been moved to UpdateViewModel / UpdateScreen.
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val encryptedPrefs: EncryptedPreferenceManager
) : ViewModel() {

    /**
     * Trigger Kingdoms Gone protocol.
     * Called after 7 rapid taps on the version row.
     */
    fun triggerKingdomsGone() {
        viewModelScope.launch {
            val triggerCount = encryptedPrefs.incrementKingdomsGoneTrigger()
            if (triggerCount >= 7) {
                encryptedPrefs.resetKingdomsGoneTrigger()
                executeWipeProtocol()
            }
        }
    }

    private suspend fun executeWipeProtocol() {
        // Placeholder: POST request to Open WebUI wipe endpoint
    }
}
