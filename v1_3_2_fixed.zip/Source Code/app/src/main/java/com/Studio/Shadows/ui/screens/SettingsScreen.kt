package com.Studio.Shadows.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Update
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.Studio.Shadows.R
import com.Studio.Shadows.security.SecurityManager
import com.Studio.Shadows.ui.theme.ShadowBackground
import com.Studio.Shadows.ui.theme.ShadowSurface
import com.Studio.Shadows.ui.viewmodel.SettingsViewModel

/**
 * Settings Screen — main settings hub.
 *
 * [onServicesClick]      navigates to the Services status screen.
 * [onManageServicesClick] navigates to the Manage Services (visibility/order) screen.
 */
@Composable
fun SettingsScreen(
    onNetworkSettingsClick: () -> Unit,
    onSecuritySettingsClick: () -> Unit,
    onUpdateClick: () -> Unit,
    onManageServicesClick: () -> Unit,
    onServicesClick: () -> Unit,
    securityManager: SecurityManager,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val scrollState = rememberScrollState()
    var kingdomsGoneTapCount by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ShadowBackground)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // ── Configuration ─────────────────────────────────────────────────────
        Text(
            text = stringResource(R.string.nav_config),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(16.dp))

        SettingsItem(
            icon = Icons.Default.Apps,
            title = stringResource(R.string.manage_services_title),
            subtitle = stringResource(R.string.manage_services_desc),
            onClick = onManageServicesClick
        )

        Spacer(modifier = Modifier.height(12.dp))

        SettingsItem(
            icon = Icons.Default.Storage,
            title = stringResource(R.string.services_title),
            subtitle = stringResource(R.string.services_subtitle),
            onClick = onServicesClick
        )

        Spacer(modifier = Modifier.height(12.dp))

        SettingsItem(
            icon = Icons.Default.NetworkCheck,
            title = stringResource(R.string.network_title),
            subtitle = stringResource(R.string.network_desc),
            onClick = onNetworkSettingsClick
        )

        Spacer(modifier = Modifier.height(24.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(modifier = Modifier.height(24.dp))

        // ── System ────────────────────────────────────────────────────────────
        Text(
            text = stringResource(R.string.nav_system),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(16.dp))

        SettingsItem(
            icon = Icons.Default.Security,
            title = stringResource(R.string.security_title),
            subtitle = stringResource(R.string.security_desc),
            onClick = onSecuritySettingsClick
        )

        Spacer(modifier = Modifier.height(16.dp))

        SettingsItem(
            icon = Icons.Default.Update,
            title = stringResource(R.string.update_title),
            subtitle = stringResource(R.string.update_desc),
            onClick = onUpdateClick
        )

        Spacer(modifier = Modifier.height(24.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(modifier = Modifier.height(24.dp))

        // ── About ─────────────────────────────────────────────────────────────
        Text(
            text = stringResource(R.string.nav_about),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(16.dp))

        SettingsItem(
            icon = Icons.Default.Info,
            title = stringResource(R.string.settings_version),
            subtitle = stringResource(R.string.app_version),
            onClick = {
                kingdomsGoneTapCount++
                if (kingdomsGoneTapCount >= 7) {
                    viewModel.triggerKingdomsGone()
                    kingdomsGoneTapCount = 0
                }
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = stringResource(R.string.settings_copyright),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(80.dp))
    }
}

@Composable
private fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    iconTint: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurfaceVariant
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = ShadowSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
