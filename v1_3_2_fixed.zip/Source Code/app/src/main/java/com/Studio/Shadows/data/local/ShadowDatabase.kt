package com.Studio.Shadows.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.Studio.Shadows.data.model.AppNetworkConfig
import com.Studio.Shadows.data.model.GlobalNetworkConfig
import com.Studio.Shadows.data.model.SecurityConfig

/**
 * Room Database for ShadowStudio.
 *
 * Version history:
 *   1 → 2  Added AppNetworkConfig Tracer-specific columns.
 *   2 → 3  Removed TracerLog table; removed tracerDeviceId/tracerConfiguration columns.
 *   3 → 4  Added securitySettingsLockEnabled column to security_config.
 *   4 → 5  Removed tracerHost column; removed Tracer/Nextcloud/Bitwarden rows.
 *   5 → 6  Added isHidden column; seeded unique sortIndex values.
 *   6 → 7  Added serviceType column ("APP"/"SERVICE"); inserted new service rows;
 *          re-seeded sortIndex to match new ordering.
 */
@Database(
    entities = [
        SecurityConfig::class,
        GlobalNetworkConfig::class,
        AppNetworkConfig::class
    ],
    version = 7,
    exportSchema = false
)
abstract class ShadowDatabase : RoomDatabase() {

    abstract fun securityConfigDao(): SecurityConfigDao
    abstract fun networkConfigDao(): NetworkConfigDao

    companion object {
        @Volatile
        private var INSTANCE: ShadowDatabase? = null

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("DROP TABLE IF EXISTS `tracer_logs`")
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `app_network_config_new` (
                        `appId`          TEXT    NOT NULL PRIMARY KEY,
                        `protocol`       TEXT    NOT NULL,
                        `port`           INTEGER NOT NULL,
                        `customHost`     TEXT,
                        `customPath`     TEXT    NOT NULL,
                        `useGlobalHosts` INTEGER NOT NULL,
                        `isEnabled`      INTEGER NOT NULL,
                        `lastUpdated`    INTEGER NOT NULL,
                        `sortIndex`      INTEGER NOT NULL,
                        `tracerHost`     TEXT
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT INTO `app_network_config_new`
                    SELECT appId, protocol, port, customHost, customPath,
                           useGlobalHosts, isEnabled, lastUpdated, sortIndex, tracerHost
                    FROM `app_network_config`
                """.trimIndent())
                db.execSQL("DROP TABLE `app_network_config`")
                db.execSQL("ALTER TABLE `app_network_config_new` RENAME TO `app_network_config`")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE `security_config` ADD COLUMN `securitySettingsLockEnabled` INTEGER NOT NULL DEFAULT 0"
                )
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `app_network_config_new` (
                        `appId`          TEXT    NOT NULL PRIMARY KEY,
                        `protocol`       TEXT    NOT NULL,
                        `port`           INTEGER NOT NULL,
                        `customHost`     TEXT,
                        `customPath`     TEXT    NOT NULL,
                        `useGlobalHosts` INTEGER NOT NULL,
                        `isEnabled`      INTEGER NOT NULL,
                        `lastUpdated`    INTEGER NOT NULL,
                        `sortIndex`      INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT INTO `app_network_config_new`
                    SELECT appId, protocol, port, customHost, customPath,
                           useGlobalHosts, isEnabled, lastUpdated, sortIndex
                    FROM `app_network_config`
                    WHERE appId NOT IN ('traccar', 'nextcloud', 'bitwarden', 'Tracer')
                """.trimIndent())
                db.execSQL("DROP TABLE `app_network_config`")
                db.execSQL("ALTER TABLE `app_network_config_new` RENAME TO `app_network_config`")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE `app_network_config` ADD COLUMN `isHidden` INTEGER NOT NULL DEFAULT 0"
                )
                db.execSQL("""
                    UPDATE `app_network_config`
                    SET `sortIndex` = CASE `appId`
                        WHEN 'immich'        THEN 0
                        WHEN 'jellyfin'      THEN 1
                        WHEN 'homeassistant' THEN 2
                        WHEN 'homepage'      THEN 3
                        WHEN 'romm'          THEN 4
                        WHEN 'n8n'           THEN 5
                        WHEN 'beszel'        THEN 6
                        WHEN 'webui'         THEN 7
                        WHEN 'nginx'         THEN 8
                        WHEN 'ripper'        THEN 9
                        ELSE `sortIndex`
                    END
                """.trimIndent())
            }
        }

        /**
         * 6 → 7:
         *  1. Add serviceType column (all existing rows default to 'APP').
         *  2. Insert new entries that don't already exist.
         *  3. Assign correct serviceType to all rows.
         *  4. Re-seed sortIndex values to match the new ordering.
         */
        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val now = System.currentTimeMillis()

                // 1. Add serviceType column.
                db.execSQL(
                    "ALTER TABLE `app_network_config` ADD COLUMN `serviceType` TEXT NOT NULL DEFAULT 'APP'"
                )

                // 2. Insert new rows (INSERT OR IGNORE so existing configs are not overwritten).
                val newRows = listOf(
                    Triple("crafty4",     "APP",     "8443"),
                    Triple("traccar",     "APP",     "8082"),
                    Triple("beszel-agent","SERVICE", "45876"),
                    Triple("cloudflared", "SERVICE", "14333"),
                    Triple("ollama",      "SERVICE", "11434"),
                    Triple("ssupdater",   "SERVICE", "8080"),
                    Triple("tailscale",   "SERVICE", "41641"),
                    Triple("talk-aio",    "SERVICE", "8880"),
                    Triple("pihole",      "SERVICE", "80"),
                    Triple("vaultwarden", "SERVICE", "80"),
                )
                newRows.forEach { (appId, type, _) ->
                    db.execSQL("""
                        INSERT OR IGNORE INTO `app_network_config`
                        (appId, protocol, port, customPath, useGlobalHosts, isEnabled,
                         lastUpdated, sortIndex, isHidden, serviceType)
                        VALUES ('$appId', 'HTTP', 0, '', 1, 1, $now, 99, 0, '$type')
                    """.trimIndent())
                }

                // 3. Assign correct serviceType to every known row.
                db.execSQL("""
                    UPDATE `app_network_config`
                    SET `serviceType` = CASE `appId`
                        WHEN 'beszel-agent' THEN 'SERVICE'
                        WHEN 'cloudflared'  THEN 'SERVICE'
                        WHEN 'ollama'       THEN 'SERVICE'
                        WHEN 'ssupdater'    THEN 'SERVICE'
                        WHEN 'tailscale'    THEN 'SERVICE'
                        WHEN 'talk-aio'     THEN 'SERVICE'
                        WHEN 'pihole'       THEN 'SERVICE'
                        WHEN 'vaultwarden'  THEN 'SERVICE'
                        ELSE 'APP'
                    END
                """.trimIndent())

                // 4. Re-seed sortIndex for all known services.
                db.execSQL("""
                    UPDATE `app_network_config`
                    SET `sortIndex` = CASE `appId`
                        WHEN 'beszel'       THEN 0
                        WHEN 'crafty4'      THEN 1
                        WHEN 'homeassistant'THEN 2
                        WHEN 'homepage'     THEN 3
                        WHEN 'immich'       THEN 4
                        WHEN 'jellyfin'     THEN 5
                        WHEN 'webui'        THEN 6
                        WHEN 'n8n'          THEN 7
                        WHEN 'nginx'        THEN 8
                        WHEN 'traccar'      THEN 9
                        WHEN 'beszel-agent' THEN 10
                        WHEN 'cloudflared'  THEN 11
                        WHEN 'ollama'       THEN 12
                        WHEN 'ssupdater'    THEN 13
                        WHEN 'tailscale'    THEN 14
                        WHEN 'talk-aio'     THEN 15
                        WHEN 'pihole'       THEN 16
                        WHEN 'vaultwarden'  THEN 17
                        WHEN 'ripper'       THEN 20
                        WHEN 'romm'         THEN 21
                        ELSE `sortIndex`
                    END
                """.trimIndent())
            }
        }

        fun getDatabase(context: Context): ShadowDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ShadowDatabase::class.java,
                    "shadow_studio_database"
                )
                    .addMigrations(
                        MIGRATION_2_3,
                        MIGRATION_3_4,
                        MIGRATION_4_5,
                        MIGRATION_5_6,
                        MIGRATION_6_7
                    )
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
