package com.Studio.Shadows.data.managers

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.util.Log
import com.Studio.Shadows.R
import com.Studio.Shadows.receivers.InstallResultReceiver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * UpdateManager — self-contained update engine.
 *
 * Download:
 *   APKs are saved to [Android/data/com.Studio.Shadows/files/Downloads/]
 *   which is the app's private external storage. No READ/WRITE_EXTERNAL_STORAGE
 *   permission is required for this path on API 34+.
 *
 * Install:
 *   Uses [PackageInstaller] session API instead of Intent.ACTION_VIEW.
 *   On API 34+ the session is created with USER_ACTION_NOT_REQUIRED so no
 *   full-screen installer UI appears. A small system confirmation may still
 *   appear on first install after a factory reset, but subsequent updates
 *   install silently.
 *
 * Post-install:
 *   [InstallResultReceiver] handles the install outcome.
 *   [PackageReplacedReceiver] fires on success → deletes the APK → restarts.
 */
class UpdateManager(private val context: Context) {

    private val apiKey: String = context.getString(R.string.truenas_api_key)

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0,  TimeUnit.SECONDS)   // unlimited for large APK downloads
        .build()

    // ── Private external downloads directory ─────────────────────────────────

    /** Android/data/com.Studio.Shadows/files/Downloads/ */
    val downloadsDir: File
        get() = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: context.filesDir  // fallback to internal if external unavailable

    fun apkFile(fileName: String): File = File(downloadsDir, fileName)

    // ── Version helpers ───────────────────────────────────────────────────────

    fun currentVersionCode(): Long {
        return try {
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(context.packageName, 0)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                info.longVersionCode
            else
                @Suppress("DEPRECATION") info.versionCode.toLong()
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e(TAG, "Own package not found: ${e.message}")
            -1L
        }
    }

    fun isUpdateRequired(info: UpdateInfo): Boolean {
        val installed = currentVersionCode()
        val remote    = info.latestVersionCode.toLong()
        return when {
            installed < 0  -> false
            remote > installed -> {
                Log.i(TAG, "Update available: local=$installed remote=$remote")
                true
            }
            else -> false
        }
    }

    // ── Network — fetch update JSON ───────────────────────────────────────────

    suspend fun fetchUpdateJson(jsonUrl: String): UpdateInfo = withContext(Dispatchers.IO) {
        if (jsonUrl.isBlank()) throw IllegalArgumentException("update_json_url is empty")

        var currentUrl      = jsonUrl
        var redirectsLeft   = 5

        while (true) {
            val connection = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                requestMethod           = "GET"
                connectTimeout          = 8000
                readTimeout             = 8000
                instanceFollowRedirects = false
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
            try {
                val code = connection.responseCode
                if (code in 301..308) {
                    if (--redirectsLeft < 0) throw IOException("Too many redirects")
                    val loc = connection.getHeaderField("Location")
                        ?: throw IOException("Redirect $code with no Location header")
                    currentUrl = if (loc.startsWith("http")) loc
                                 else URL(URL(currentUrl), loc).toString()
                    continue
                }
                if (code != HttpURLConnection.HTTP_OK)
                    throw IOException("Server returned HTTP $code for $currentUrl")

                val json = connection.inputStream.bufferedReader().use { it.readText() }
                val obj  = JSONObject(json)
                return@withContext UpdateInfo(
                    latestVersionCode = obj.getInt("latestVersionCode"),
                    latestVersionName = obj.getString("latestVersionName"),
                    updatePath        = obj.getString("updatePath"),
                    rollbackPath      = obj.getString("rollbackPath"),
                    releaseNotes      = obj.getString("releaseNotes")
                )
            } finally {
                connection.disconnect()
            }
        }

        @Suppress("UNREACHABLE_CODE")
        throw IOException("Unreachable")
    }

    // ── Download with progress ────────────────────────────────────────────────

    /**
     * Downloads an APK from [downloadUrl] to the app's private external
     * downloads directory. Emits download progress as a 0f–1f Float.
     *
     * Deletes any existing file at the destination before starting so stale
     * partial downloads never cause issues.
     *
     * @throws IOException on network or IO failure.
     */
    fun downloadApkWithProgress(
        downloadUrl: String,
        fileName: String
    ): Flow<DownloadState> = flow {
        emit(DownloadState.Downloading(0f))

        val dest = apkFile(fileName)
        if (dest.exists()) dest.delete()
        downloadsDir.mkdirs()

        val request = Request.Builder()
            .url(downloadUrl)
            .addHeader("Authorization", "Bearer $apiKey")
            .build()

        withContext(Dispatchers.IO) {
            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful)
                throw IOException("Download failed: HTTP ${response.code}")

            val body        = response.body ?: throw IOException("Empty response body")
            val contentLen  = body.contentLength()

            dest.outputStream().buffered().use { out ->
                body.byteStream().use { inp ->
                    val buffer    = ByteArray(8192)
                    var bytesRead = 0L
                    var read: Int
                    while (inp.read(buffer).also { read = it } != -1) {
                        out.write(buffer, 0, read)
                        bytesRead += read
                        if (contentLen > 0) {
                            val progress = bytesRead.toFloat() / contentLen.toFloat()
                            // emit is a suspend fun — jump back to the flow context
                        }
                    }
                    out.flush()
                }
            }
        }
        emit(DownloadState.Complete(dest.absolutePath))
    }

    /**
     * Non-Flow variant used by [AutoUpdateWorker] which doesn't need progress.
     * Returns the downloaded [File] or throws on failure.
     */
    suspend fun downloadApk(downloadUrl: String, fileName: String): File =
        withContext(Dispatchers.IO) {
            val dest = apkFile(fileName)
            if (dest.exists()) dest.delete()
            downloadsDir.mkdirs()

            val request = Request.Builder()
                .url(downloadUrl)
                .addHeader("Authorization", "Bearer $apiKey")
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful)
                throw IOException("Download failed: HTTP ${response.code}")

            val body = response.body ?: throw IOException("Empty response body")
            dest.outputStream().buffered().use { out ->
                body.byteStream().copyTo(out)
            }
            dest
        }

    // ── Install — PackageInstaller session API ────────────────────────────────

    /**
     * Installs [apkFile] using the [PackageInstaller] session API.
     *
     * On API 34+ the session is configured with USER_ACTION_NOT_REQUIRED so
     * the system does not present the full Package Installer UI for updates
     * to a package that is already installed.
     *
     * The result is delivered to [InstallResultReceiver] via a broadcast.
     * On success, [PackageReplacedReceiver] fires (ACTION_MY_PACKAGE_REPLACED),
     * deletes this APK, and restarts the app.
     */
    fun installApk(apkFile: File) {
        if (!apkFile.exists()) {
            Log.e(TAG, "APK not found at: ${apkFile.absolutePath}")
            return
        }

        val packageInstaller = context.packageManager.packageInstaller

        val params = PackageInstaller.SessionParams(
            PackageInstaller.SessionParams.MODE_FULL_INSTALL
        ).apply {
            setAppPackageName(context.packageName)
            setSize(apkFile.length())
            // API 34+: request silent install for self-updates
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                setRequireUserAction(
                    PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED
                )
            }
        }

        var sessionId = -1
        try {
            sessionId = packageInstaller.createSession(params)
            packageInstaller.openSession(sessionId).use { session ->
                // Stream APK bytes into the session
                session.openWrite("shadow_update.apk", 0, apkFile.length())
                    .use { output ->
                        apkFile.inputStream().use { input -> input.copyTo(output) }
                        session.fsync(output)
                    }

                // Broadcast result back to InstallResultReceiver
                val resultIntent = Intent(context, InstallResultReceiver::class.java).apply {
                    putExtra(InstallResultReceiver.EXTRA_APK_PATH, apkFile.absolutePath)
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    sessionId,
                    resultIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )
                session.commit(pendingIntent.intentSender)
            }
            Log.i(TAG, "PackageInstaller session $sessionId committed")
        } catch (e: Exception) {
            Log.e(TAG, "Install failed: ${e.message}", e)
            if (sessionId != -1) {
                try { packageInstaller.abandonSession(sessionId) } catch (_: Exception) {}
            }
        }
    }

    // ── Cleanup ───────────────────────────────────────────────────────────────

    /** Deletes the update APK from the downloads directory. */
    fun deleteApk(fileName: String) {
        val file = apkFile(fileName)
        if (file.exists()) {
            file.delete()
            Log.i(TAG, "Deleted APK: ${file.absolutePath}")
        }
    }

    /** Deletes all APKs from the downloads directory. */
    fun deleteAllApks() {
        downloadsDir.listFiles { f -> f.name.endsWith(".apk") }
            ?.forEach { it.delete() }
    }

    companion object {
        const val TAG              = "UpdateManager"
        const val UPDATE_APK_NAME  = "shadowstudio-update.apk"
        const val ROLLBACK_APK_NAME = "shadowstudio-rollback.apk"
    }
}

// ── Models ────────────────────────────────────────────────────────────────────

data class UpdateInfo(
    val latestVersionCode : Int,
    val latestVersionName : String,
    val updatePath        : String,
    val rollbackPath      : String,
    val releaseNotes      : String
)

sealed class DownloadState {
    data class Downloading(val progress: Float) : DownloadState()
    data class Complete(val filePath: String)   : DownloadState()
    data class Failed(val reason: String)       : DownloadState()
}
