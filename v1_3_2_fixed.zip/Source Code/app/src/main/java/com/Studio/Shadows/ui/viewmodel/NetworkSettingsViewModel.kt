package com.Studio.Shadows.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.Studio.Shadows.data.model.AppNetworkConfig
import com.Studio.Shadows.data.model.ConnectionResult
import com.Studio.Shadows.data.model.GlobalNetworkConfig
import com.Studio.Shadows.data.repository.NetworkConfigRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Network Settings screen.
 *
 * Exposes two separate config lists so the screen can show them in distinct
 * "Apps" and "Services" expandable sections:
 *   [appConfigs]     — visible App-type entries
 *   [serviceConfigs] — visible Service-type entries
 */
@HiltViewModel
class NetworkSettingsViewModel @Inject constructor(
    private val repository: NetworkConfigRepository
) : ViewModel() {

    val globalConfig: StateFlow<GlobalNetworkConfig?> = repository
        .getGlobalConfigFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = null
        )

    /** Visible App-type entries — shown in the "Apps" dropdown section. */
    val appConfigs: StateFlow<List<AppNetworkConfig>> = repository
        .getVisibleAppsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    /** Visible Service-type entries — shown in the "Services" dropdown section. */
    val serviceConfigs: StateFlow<List<AppNetworkConfig>> = repository
        .getVisibleServicesFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    private val _pendingProtocols = MutableStateFlow<Map<String, String>>(emptyMap())
    private val _pendingPorts = MutableStateFlow<Map<String, Int>>(emptyMap())

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    private val _saveResult = MutableStateFlow<Boolean?>(null)
    val saveResult: StateFlow<Boolean?> = _saveResult.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaults()
        }
    }

    fun updateAppProtocol(appId: String, protocol: String) {
        _pendingProtocols.value = _pendingProtocols.value + (appId to protocol)
    }

    fun updateAppPort(appId: String, port: Int) {
        _pendingPorts.value = _pendingPorts.value + (appId to port)
    }

    fun saveConfiguration(primaryHost: String, backupHost: String) {
        viewModelScope.launch {
            _isSaving.value = true
            try {
                repository.updatePrimaryHost(primaryHost.trim())
                repository.updateBackupHost(backupHost.trim())

                val protocols = _pendingProtocols.value
                val ports = _pendingPorts.value
                val allIds = (protocols.keys + ports.keys).toSet()
                allIds.forEach { appId ->
                    val currentConfig = repository.getAppConfig(appId) ?: return@forEach
                    val protocol = protocols[appId] ?: currentConfig.protocol
                    val port = ports[appId] ?: currentConfig.port
                    repository.updateAppProtocolAndPort(appId, protocol, port)
                }

                _pendingProtocols.value = emptyMap()
                _pendingPorts.value = emptyMap()
                _saveResult.value = true
            } catch (e: Exception) {
                _saveResult.value = false
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun clearSaveResult() { _saveResult.value = null }

    suspend fun testConnection(appId: String): ConnectionResult {
        val serviceUrl = repository.buildServiceUrlWithFailover(appId)
        if (!serviceUrl.isValid || serviceUrl.url.isBlank()) {
            return ConnectionResult.Error(
                Exception("No URL configured"),
                "Configure a host and port first"
            )
        }
        return repository.testConnection(serviceUrl.url)
    }
}
