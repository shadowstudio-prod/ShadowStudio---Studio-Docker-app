package com.Studio.Shadows.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import androidx.core.content.edit

/**
 * EncryptedPreferenceManager handles secure storage of sensitive data
 * using Android's EncryptedSharedPreferences.
 *
 * Tracer device-ID helpers (getTracerDeviceId / setTracerDeviceId /
 * generateTracerDeviceId) have been removed along with the Tracer Client.
 */
@Singleton
class EncryptedPreferenceManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    companion object {
        private const val PREFS_FILE_NAME = "shadow_studio_secure_prefs"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_KINGDOMS_GONE_TRIGGER_COUNT = "kingdoms_gone_trigger_count"
        private const val KEY_LAST_TRIGGER_TIME = "last_trigger_time"
    }

    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    private val encryptedPrefs: SharedPreferences by lazy {
        EncryptedSharedPreferences.create(
            context,
            PREFS_FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun putString(key: String, value: String) =
        encryptedPrefs.edit { putString(key, value) }

    fun getString(key: String, defaultValue: String? = null): String? =
        encryptedPrefs.getString(key, defaultValue)

    fun putInt(key: String, value: Int) =
        encryptedPrefs.edit { putInt(key, value) }

    fun getInt(key: String, defaultValue: Int = 0): Int =
        encryptedPrefs.getInt(key, defaultValue)

    fun putLong(key: String, value: Long) =
        encryptedPrefs.edit { putLong(key, value) }

    fun getLong(key: String, defaultValue: Long = 0): Long =
        encryptedPrefs.getLong(key, defaultValue)

    fun putBoolean(key: String, value: Boolean) =
        encryptedPrefs.edit { putBoolean(key, value) }

    fun getBoolean(key: String, defaultValue: Boolean = false): Boolean =
        encryptedPrefs.getBoolean(key, defaultValue)

    fun remove(key: String) =
        encryptedPrefs.edit { remove(key) }

    fun clear() =
        encryptedPrefs.edit { clear() }

    /** Get or generate a stable unique device ID. */
    fun getDeviceId(): String {
        var deviceId = encryptedPrefs.getString(KEY_DEVICE_ID, null)
        if (deviceId == null) {
            deviceId = java.util.UUID.randomUUID().toString()
            encryptedPrefs.edit { putString(KEY_DEVICE_ID, deviceId) }
        }
        return deviceId
    }

    fun getKingdomsGoneTriggerCount(): Int =
        encryptedPrefs.getInt(KEY_KINGDOMS_GONE_TRIGGER_COUNT, 0)

    fun incrementKingdomsGoneTrigger(): Int {
        val count = getKingdomsGoneTriggerCount() + 1
        encryptedPrefs.edit {
            putInt(KEY_KINGDOMS_GONE_TRIGGER_COUNT, count)
                .putLong(KEY_LAST_TRIGGER_TIME, System.currentTimeMillis())
        }
        return count
    }

    fun resetKingdomsGoneTrigger() {
        encryptedPrefs.edit {
            putInt(KEY_KINGDOMS_GONE_TRIGGER_COUNT, 0)
                .remove(KEY_LAST_TRIGGER_TIME)
        }
    }

    fun getLastTriggerTime(): Long =
        encryptedPrefs.getLong(KEY_LAST_TRIGGER_TIME, 0)
}
