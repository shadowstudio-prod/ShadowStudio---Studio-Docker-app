package com.Studio.Shadows.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Error
import androidx.compose.material.icons.outlined.OpenInBrowser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.Studio.Shadows.R
import com.Studio.Shadows.data.model.AppModel
import com.Studio.Shadows.data.model.AppStatus
import com.Studio.Shadows.ui.theme.ShadowBackground
import com.Studio.Shadows.ui.theme.ShadowError
import com.Studio.Shadows.ui.theme.ShadowPrimary
import com.Studio.Shadows.ui.theme.ShadowSuccess
import com.Studio.Shadows.ui.theme.ShadowSurface
import com.Studio.Shadows.ui.theme.getServiceColor
import com.Studio.Shadows.ui.viewmodel.ServicesViewModel

/**
 * Services Screen.
 *
 * Mirrors the Home screen layout but shows Service-type entries only.
 * Most cards are status-only. VaultWarden and Pi-Hole ([AppModel.openInWebView] = true)
 * are tappable and navigate to a WebView via [onServiceClick].
 */
@Composable
fun ServicesScreen(
    onServiceClick: (String) -> Unit,
    viewModel: ServicesViewModel = hiltViewModel()
) {
    val services by viewModel.services.collectAsState()
    val serviceStatuses by viewModel.serviceStatuses.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ShadowBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            item {
                ServicesHeaderSection(
                    onlineCount = serviceStatuses.count { it.value.isOnline },
                    totalCount = services.size
                )
            }

            // Stats
            item {
                QuickStatsRowServices(
                    onlineCount = serviceStatuses.count { it.value.isOnline },
                    offlineCount = serviceStatuses.count { !it.value.isOnline }
                )
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }

            // Service cards
            items(services) { service ->
                val status = serviceStatuses[service.id] ?: AppStatus(service.id)
                ServiceItemCard(
                    service = service,
                    status = status,
                    isLoading = isRefreshing,
                    onServiceClick = if (service.openInWebView) {
                        { onServiceClick(service.id) }
                    } else null
                )
            }

            item { Spacer(modifier = Modifier.height(80.dp)) }
        }

        // Refresh FAB
        FloatingActionButton(
            onClick = { viewModel.refreshStatuses() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = ShadowPrimary
        ) {
            if (isRefreshing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
            } else {
                Icon(
                    Icons.Default.Refresh,
                    contentDescription = stringResource(R.string.home_refresh)
                )
            }
        }
    }
}

@Composable
private fun ServicesHeaderSection(onlineCount: Int, totalCount: Int) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = stringResource(R.string.services_title),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "$onlineCount of $totalCount services online",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun QuickStatsRowServices(onlineCount: Int, offlineCount: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ServicesStatCard(
            title = stringResource(R.string.home_services_online),
            count = onlineCount,
            color = ShadowSuccess,
            modifier = Modifier.weight(1f)
        )
        ServicesStatCard(
            title = stringResource(R.string.home_services_offline),
            count = offlineCount,
            color = if (offlineCount > 0) ShadowError else ShadowSuccess.copy(alpha = 0.5f),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun ServicesStatCard(
    title: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = ShadowSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.headlineLarge,
                color = color
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * A single service row card.
 *
 * If [onServiceClick] is non-null the card is tappable (VaultWarden, Pi-Hole)
 * and shows a small "open" icon to indicate it has a GUI. Otherwise, it is
 * status-only and not clickable.
 */
@Composable
private fun ServiceItemCard(
    service: AppModel,
    status: AppStatus,
    isLoading: Boolean,
    onServiceClick: (() -> Unit)?
) {
    val serviceColor = getServiceColor(service.id)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (onServiceClick != null)
                    Modifier.clickable(onClick = onServiceClick)
                else
                    Modifier
            ),
        colors = CardDefaults.cardColors(containerColor = ShadowSurface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(serviceColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(service.iconResId),
                    contentDescription = null,
                    modifier = Modifier.size(28.dp),
                    tint = serviceColor
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Name + description
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(service.nameResId),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = stringResource(service.descriptionResId),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // WebView indicator for tappable services
            if (onServiceClick != null) {
                Icon(
                    imageVector = Icons.Outlined.OpenInBrowser,
                    contentDescription = "Opens in browser",
                    tint = serviceColor.copy(alpha = 0.7f),
                    modifier = Modifier
                        .size(18.dp)
                        .padding(end = 4.dp)
                )
            }

            // Status indicator
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = serviceColor
                )
            } else {
                Icon(
                    imageVector = if (status.isOnline) Icons.Outlined.CheckCircle
                                  else Icons.Outlined.Error,
                    contentDescription = if (status.isOnline) "Online" else "Offline",
                    tint = if (status.isOnline) ShadowSuccess else ShadowError,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
