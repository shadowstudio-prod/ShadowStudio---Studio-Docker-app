package com.Studio.Shadows.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/**
 * Dark color scheme for ShadowStudio (always dark)
 */
private val DarkColorScheme = darkColorScheme(
    primary = ShadowPrimary,
    onPrimary = OnShadowPrimary,
    primaryContainer = ShadowPrimaryContainer,
    onPrimaryContainer = OnShadowPrimary,
    secondary = ShadowSecondary,
    onSecondary = OnShadowSecondary,
    secondaryContainer = ShadowSecondaryContainer,
    onSecondaryContainer = OnShadowSecondary,
    tertiary = ShadowTertiary,
    onTertiary = OnShadowTertiary,
    tertiaryContainer = ShadowTertiaryContainer,
    onTertiaryContainer = OnShadowTertiary,
    background = ShadowBackground,
    onBackground = OnShadowBackground,
    surface = ShadowSurface,
    onSurface = OnShadowSurface,
    surfaceVariant = ShadowSurfaceVariant,
    onSurfaceVariant = OnShadowSurfaceVariant,
    surfaceTint = ShadowPrimary,
    inverseSurface = OnShadowBackground,
    inverseOnSurface = ShadowBackground,
    error = ShadowError,
    onError = OnShadowError,
    errorContainer = ShadowErrorContainer,
    onErrorContainer = OnShadowError,
    outline = ShadowOutline,
    outlineVariant = ShadowOutlineVariant,
    scrim = ShadowScrim
)

/**
 * ShadowStudio Theme
 * Always uses dark theme regardless of system setting
 */
@Composable
fun ShadowStudioTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = ShadowBackground.toArgb()
            window.navigationBarColor = ShadowBackground.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

/**
 * Check if the theme is in dark mode (always true for ShadowStudio)
 */
@Composable
fun isShadowDarkTheme(): Boolean = true
