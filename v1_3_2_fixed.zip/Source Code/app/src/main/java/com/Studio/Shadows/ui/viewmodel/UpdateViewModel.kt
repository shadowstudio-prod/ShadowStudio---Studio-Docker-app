package com.Studio.Shadows.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.Studio.Shadows.R
import com.Studio.Shadows.data.managers.DownloadState
import com.Studio.Shadows.data.managers.UpdateInfo
import com.Studio.Shadows.data.managers.UpdateManager
import com.Studio.Shadows.data.preferences.UpdatePreferences
import com.Studio.Shadows.workers.AutoUpdateWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar
import java.util.concurrent.TimeUnit

class UpdateViewModel(application: Application) : AndroidViewModel(application) {

    private val updateManager  = UpdateManager(application)
    private val updatePrefs    = UpdatePreferences(application)
    private val workManager    = WorkManager.getInstance(application)
    private val jsonUrl: String = application.getString(R.string.update_json_url)

    // ── Download / install state ──────────────────────────────────────────────

    private val _updateProgress    = MutableStateFlow<Float?>(null)
    val updateProgress: StateFlow<Float?> = _updateProgress.asStateFlow()

    private val _rollbackProgress  = MutableStateFlow<Float?>(null)
    val rollbackProgress: StateFlow<Float?> = _rollbackProgress.asStateFlow()

    private val _developerLogs     = MutableStateFlow<List<String>>(emptyList())
    val developerLogs: StateFlow<List<String>> = _developerLogs.asStateFlow()

    private val _releaseNotes      = MutableStateFlow("-- Tap Check for Update to load version info --")
    val releaseNotes: StateFlow<String> = _releaseNotes.asStateFlow()

    private val _latestVersionName = MutableStateFlow("")
    val latestVersionName: StateFlow<String> = _latestVersionName.asStateFlow()

    private val _isCheckingUpdate  = MutableStateFlow(false)
    val isCheckingUpdate: StateFlow<Boolean> = _isCheckingUpdate.asStateFlow()

    // Set to true while a download is in progress — used to disable buttons
    private val _isBusy            = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    // ── Auto-update preferences (from DataStore) ──────────────────────────────

    val autoUpdateEnabled: StateFlow<Boolean> = updatePrefs.autoUpdateEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    val scheduledHour: StateFlow<Int> = updatePrefs.scheduledHour
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UpdatePreferences.DEFAULT_HOUR)

    val scheduledMinute: StateFlow<Int> = updatePrefs.scheduledMinute
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UpdatePreferences.DEFAULT_MINUTE)

    // ── Auto-update control ───────────────────────────────────────────────────

    /**
     * Enables or disables the daily auto-update.
     * When enabled, schedules a [AutoUpdateWorker] for the next occurrence
     * of the user's chosen time. When disabled, cancels any pending work.
     */
    fun setAutoUpdateEnabled(enabled: Boolean) {
        viewModelScope.launch {
            updatePrefs.setAutoUpdateEnabled(enabled)
            if (enabled) {
                scheduleAutoUpdate()
                addLog("[Auto-Update] Enabled — scheduled for ${formatTime(scheduledHour.value, scheduledMinute.value)}")
            } else {
                workManager.cancelUniqueWork(AutoUpdateWorker.WORK_NAME)
                addLog("[Auto-Update] Disabled — scheduled job cancelled")
            }
        }
    }

    /**
     * Updates the scheduled install time and re-schedules the worker if
     * auto-update is currently enabled.
     */
    fun setScheduledTime(hour: Int, minute: Int) {
        viewModelScope.launch {
            updatePrefs.setScheduledTime(hour, minute)
            addLog("[Auto-Update] Schedule updated to ${formatTime(hour, minute)}")
            if (autoUpdateEnabled.value) {
                scheduleAutoUpdate()
            }
        }
    }

    /**
     * Schedules a [OneTimeWorkRequest] for the next occurrence of the stored
     * scheduled time. If that time has already passed today, schedules for
     * tomorrow. The worker reschedules itself on completion for the day after.
     */
    private fun scheduleAutoUpdate() {
        val hour   = scheduledHour.value
        val minute = scheduledMinute.value
        val delay  = millisUntilNextOccurrence(hour, minute)

        val request = OneTimeWorkRequestBuilder<AutoUpdateWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()

        workManager.enqueueUniqueWork(
            AutoUpdateWorker.WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
        Log.i(TAG, "Auto-update scheduled in ${delay / 60_000} min (at ${formatTime(hour, minute)})")
    }

    // ── Manual update / rollback ──────────────────────────────────────────────

    fun checkForUpdate() {
        viewModelScope.launch {
            _isCheckingUpdate.value = true
            addLog("[Check] Fetching update info…")
            try {
                val info = updateManager.fetchUpdateJson(jsonUrl)
                _releaseNotes.value      = info.releaseNotes
                _latestVersionName.value = info.latestVersionName
                if (updateManager.isUpdateRequired(info)) {
                    addLog("[Check] Update available: v${info.latestVersionName}")
                } else {
                    addLog("[Check] Already up to date")
                }
            } catch (e: Exception) {
                addLog("[Check] FAILED: ${e.message}")
            } finally {
                _isCheckingUpdate.value = false
            }
        }
    }

    fun startUpdate() {
        viewModelScope.launch {
            if (_isBusy.value) return@launch
            _isBusy.value = true
            addLog("[Update] Fetching update info…")
            try {
                val info = fetchAndLog() ?: return@launch
                if (!updateManager.isUpdateRequired(info)) {
                    addLog("[Update] Already up to date — nothing to install")
                    return@launch
                }
                downloadAndInstall(
                    url          = info.updatePath,
                    fileName     = UpdateManager.UPDATE_APK_NAME,
                    tag          = "Update",
                    progressFlow = _updateProgress
                )
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun startRollback() {
        viewModelScope.launch {
            if (_isBusy.value) return@launch
            _isBusy.value = true
            addLog("[Rollback] Fetching rollback info…")
            try {
                val info = fetchAndLog() ?: return@launch
                downloadAndInstall(
                    url      = info.rollbackPath,
                    fileName = UpdateManager.ROLLBACK_APK_NAME,
                    tag      = "Rollback",
                    progressFlow = _rollbackProgress
                )
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun cancelDownload() {
        // OkHttp downloads don't have a cancel handle at ViewModel level —
        // setting isBusy false allows a new operation to start; the coroutine
        // will be cancelled naturally when the ViewModel is cleared.
        _updateProgress.value   = null
        _rollbackProgress.value = null
        _isBusy.value           = false
        addLog("[System] Download cancelled by user")
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private suspend fun fetchAndLog(): UpdateInfo? {
        return try {
            val info = updateManager.fetchUpdateJson(jsonUrl)
            _releaseNotes.value      = info.releaseNotes
            _latestVersionName.value = info.latestVersionName
            addLog("[Fetch] Latest: v${info.latestVersionName}")
            info
        } catch (e: Exception) {
            addLog("[Fetch] FAILED: ${e.message}")
            null
        }
    }

    private suspend fun downloadAndInstall(
        url: String,
        fileName: String,
        tag: String,
        progressFlow: MutableStateFlow<Float?>
    ) {
        addLog("[$tag] Starting download from: $url")
        addLog("[$tag] Destination: ${updateManager.downloadsDir.absolutePath}/$fileName")

        try {
            // Download using OkHttp with coroutine-based progress
            withContext(Dispatchers.IO) {
                val dest = updateManager.apkFile(fileName)
                if (dest.exists()) dest.delete()
                updateManager.downloadsDir.mkdirs()

                val okHttp  = okhttp3.OkHttpClient.Builder()
                    .connectTimeout(15, TimeUnit.SECONDS)
                    .readTimeout(0, TimeUnit.SECONDS)
                    .build()
                val apiKey  = getApplication<Application>().getString(R.string.truenas_api_key)
                val request = okhttp3.Request.Builder()
                    .url(url)
                    .addHeader("Authorization", "Bearer $apiKey")
                    .build()

                val response = okHttp.newCall(request).execute()
                if (!response.isSuccessful) throw Exception("HTTP ${response.code}")

                val body       = response.body ?: throw Exception("Empty response body")
                val totalBytes = body.contentLength()
                var downloaded = 0L

                dest.outputStream().buffered().use { out ->
                    body.byteStream().use { inp ->
                        val buf = ByteArray(32_768)
                        var read: Int
                        while (inp.read(buf).also { read = it } != -1) {
                            out.write(buf, 0, read)
                            downloaded += read
                            if (totalBytes > 0) {
                                progressFlow.value = downloaded.toFloat() / totalBytes.toFloat()
                            }
                        }
                        out.flush()
                    }
                }
            }

            progressFlow.value = null
            val dest = updateManager.apkFile(fileName)
            addLog("[$tag] Download complete (${dest.length() / 1024} KB)")
            addLog("[$tag] Starting PackageInstaller session…")
            updateManager.installApk(dest)
            addLog("[$tag] Install session committed — awaiting system confirmation")
            addLog("[$tag] App will restart automatically after install")

        } catch (e: Exception) {
            progressFlow.value = null
            addLog("[$tag] FAILED: ${e.message}")
        }
    }

    private fun addLog(message: String) {
        _developerLogs.value = _developerLogs.value + message
    }

    private fun millisUntilNextOccurrence(hour: Int, minute: Int): Long {
        val now    = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE,      minute)
            set(Calendar.SECOND,      0)
            set(Calendar.MILLISECOND, 0)
        }
        if (!target.after(now)) target.add(Calendar.DAY_OF_YEAR, 1)
        return target.timeInMillis - now.timeInMillis
    }

    private fun formatTime(hour: Int, minute: Int): String =
        "%02d:%02d".format(hour, minute)

    companion object {
        private const val TAG = "UpdateViewModel"
    }
}
