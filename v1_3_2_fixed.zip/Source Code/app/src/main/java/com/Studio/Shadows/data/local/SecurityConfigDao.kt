package com.Studio.Shadows.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.Studio.Shadows.data.model.SecurityConfig
import kotlinx.coroutines.flow.Flow

@Dao
interface SecurityConfigDao {

    @Query("SELECT * FROM security_config WHERE id = 1")
    fun getConfigFlow(): Flow<SecurityConfig?>

    @Query("SELECT * FROM security_config WHERE id = 1")
    suspend fun getConfig(): SecurityConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfig(config: SecurityConfig)

    @Update
    suspend fun updateConfig(config: SecurityConfig)

    @Query("UPDATE security_config SET lastAuthenticated = :timestamp WHERE id = 1")
    suspend fun updateLastAuthenticated(timestamp: Long)

    @Query("UPDATE security_config SET failedAttempts = :attempts, lastFailedAttempt = :timestamp WHERE id = 1")
    suspend fun updateFailedAttempts(attempts: Int, timestamp: Long)

    @Query("UPDATE security_config SET failedAttempts = 0 WHERE id = 1")
    suspend fun resetFailedAttempts()

    @Query("UPDATE security_config SET biometricEnabled = :enabled WHERE id = 1")
    suspend fun setBiometricEnabled(enabled: Boolean)

    @Query("UPDATE security_config SET pinEnabled = :enabled, pinHash = :pinHash WHERE id = 1")
    suspend fun setPinEnabled(enabled: Boolean, pinHash: String?)

    @Query("UPDATE security_config SET globalLockEnabled = :enabled WHERE id = 1")
    suspend fun setGlobalLockEnabled(enabled: Boolean)

    @Query("UPDATE security_config SET securitySettingsLockEnabled = :enabled WHERE id = 1")
    suspend fun setSecuritySettingsLockEnabled(enabled: Boolean)

    @Query("UPDATE security_config SET stealthModeEnabled = :enabled WHERE id = 1")
    suspend fun setStealthModeEnabled(enabled: Boolean)

    @Query("UPDATE security_config SET killSwitchEnabled = :enabled WHERE id = 1")
    suspend fun setKillSwitchEnabled(enabled: Boolean)

    @Query("UPDATE security_config SET autoLockEnabled = :enabled WHERE id = 1")
    suspend fun setAutoLockEnabled(enabled: Boolean)

    @Query("UPDATE security_config SET sessionTimeoutMinutes = :minutes WHERE id = 1")
    suspend fun setSessionTimeout(minutes: Int)
}
