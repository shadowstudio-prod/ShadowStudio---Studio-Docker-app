package com.Studio.Shadows.data.repository

import android.content.Context
import com.Studio.Shadows.data.local.NetworkConfigDao
import com.Studio.Shadows.data.model.AppNetworkConfig
import com.Studio.Shadows.data.model.ConnectionResult
import com.Studio.Shadows.data.model.DefaultAppConfigs
import com.Studio.Shadows.data.model.GlobalNetworkConfig
import com.Studio.Shadows.data.model.ServiceUrl
import com.Studio.Shadows.data.model.buildUrl
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkConfigRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val networkConfigDao: NetworkConfigDao
) {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // ── Global Config ─────────────────────────────────────────────────────────

    fun getGlobalConfigFlow(): Flow<GlobalNetworkConfig?> = networkConfigDao.getGlobalConfigFlow()

    suspend fun getGlobalConfig(): GlobalNetworkConfig? = networkConfigDao.getGlobalConfig()

    suspend fun saveGlobalConfig(config: GlobalNetworkConfig) =
        networkConfigDao.insertGlobalConfig(config)

    suspend fun updatePrimaryHost(host: String) = networkConfigDao.updatePrimaryHost(host)

    suspend fun updateBackupHost(host: String) = networkConfigDao.updateBackupHost(host)

    // ── App Config — All ──────────────────────────────────────────────────────

    fun getAllAppConfigsFlow(): Flow<List<AppNetworkConfig>> =
        networkConfigDao.getAllAppConfigsFlow()

    suspend fun getAllAppConfigs(): List<AppNetworkConfig> = networkConfigDao.getAllAppConfigs()

    // ── App Config — Visible, all types ──────────────────────────────────────

    fun getVisibleAppConfigsFlow(): Flow<List<AppNetworkConfig>> =
        networkConfigDao.getVisibleAppConfigsFlow()

    suspend fun getVisibleAppConfigs(): List<AppNetworkConfig> =
        networkConfigDao.getVisibleAppConfigs()

    // ── App Config — Visible, filtered by serviceType ────────────────────────

    /** Visible App-type entries only. Used by HomeViewModel and DrawerViewModel. */
    fun getVisibleAppsFlow(): Flow<List<AppNetworkConfig>> =
        networkConfigDao.getVisibleConfigsByTypeFlow("APP")

    suspend fun getVisibleApps(): List<AppNetworkConfig> =
        networkConfigDao.getVisibleConfigsByType("APP")

    /** Visible Service-type entries only. Used by ServicesViewModel. */
    fun getVisibleServicesFlow(): Flow<List<AppNetworkConfig>> =
        networkConfigDao.getVisibleConfigsByTypeFlow("SERVICE")

    suspend fun getVisibleServices(): List<AppNetworkConfig> =
        networkConfigDao.getVisibleConfigsByType("SERVICE")

    // ── App Config — Single ───────────────────────────────────────────────────

    suspend fun getAppConfig(appId: String): AppNetworkConfig? =
        networkConfigDao.getAppConfig(appId)

    fun getAppConfigFlow(appId: String): Flow<AppNetworkConfig?> =
        networkConfigDao.getAppConfigFlow(appId)

    // ── App Config — Write ────────────────────────────────────────────────────

    suspend fun saveAppConfig(config: AppNetworkConfig) =
        networkConfigDao.insertAppConfig(config)

    suspend fun saveAllAppConfigs(configs: List<AppNetworkConfig>) =
        networkConfigDao.insertAllAppConfigs(configs)

    suspend fun updateAppProtocolAndPort(appId: String, protocol: String, port: Int) =
        networkConfigDao.updateAppProtocolAndPort(appId, protocol, port)

    suspend fun setAppEnabled(appId: String, enabled: Boolean) =
        networkConfigDao.setAppEnabled(appId, enabled)

    suspend fun setAppHidden(appId: String, isHidden: Boolean) =
        networkConfigDao.setAppHidden(appId, isHidden)

    suspend fun updateSortOrder(configs: List<AppNetworkConfig>) {
        val reindexed = configs.mapIndexed { index, config ->
            config.copy(sortIndex = index)
        }
        networkConfigDao.updateAllAppConfigs(reindexed)
    }

    // ── URL Building ──────────────────────────────────────────────────────────

    suspend fun buildServiceUrl(appId: String): ServiceUrl {
        val globalConfig = getGlobalConfig() ?: GlobalNetworkConfig()
        val appConfig = resolveAppConfig(appId)
            ?: return ServiceUrl(appId, "", isValid = false)
        val host = globalConfig.primaryHost
        if (host.isBlank()) return ServiceUrl(appId, "", isValid = false)
        return appConfig.buildUrl(host, globalConfig)
    }

    suspend fun buildServiceUrlWithFailover(appId: String): ServiceUrl {
        val globalConfig = getGlobalConfig() ?: GlobalNetworkConfig()
        val appConfig = resolveAppConfig(appId)
            ?: return ServiceUrl(appId, "", isValid = false)

        val primaryHost = globalConfig.primaryHost
        val backupHost = globalConfig.backupHost

        if (primaryHost.isBlank() && backupHost.isBlank()) {
            return ServiceUrl(appId, "", isValid = false)
        }

        if (primaryHost.isNotBlank() && isHostReachable(primaryHost, appConfig.port)) {
            return appConfig.buildUrl(primaryHost, globalConfig)
        }

        if (!globalConfig.failoverEnabled) {
            return appConfig.buildUrl(primaryHost, globalConfig)
        }

        if (backupHost.isNotBlank()) {
            return appConfig.buildUrl(backupHost, globalConfig).copy(isUsingBackup = true)
        }

        return appConfig.buildUrl(primaryHost, globalConfig)
    }

    // ── Connection Testing ────────────────────────────────────────────────────

    suspend fun testConnection(url: String): ConnectionResult = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).head().build()
            val startTime = System.currentTimeMillis()
            val response = okHttpClient.newCall(request).execute()
            val responseTime = System.currentTimeMillis() - startTime
            if (response.isSuccessful || response.code in 400..499)
                ConnectionResult.Success(responseTime)
            else
                ConnectionResult.Error(Exception("HTTP ${response.code}"), "Server returned ${response.code}")
        } catch (e: java.net.SocketTimeoutException) {
            ConnectionResult.Error(e, "Connection timed out", isTimeout = true)
        } catch (e: Exception) {
            ConnectionResult.Error(e, e.message ?: "Unknown error")
        }
    }

    suspend fun testHostConnection(host: String, port: Int): ConnectionResult =
        withContext(Dispatchers.IO) {
            try {
                val startTime = System.currentTimeMillis()
                Socket().use { it.connect(InetSocketAddress(host, port), 10000) }
                ConnectionResult.Success(System.currentTimeMillis() - startTime)
            } catch (e: java.net.SocketTimeoutException) {
                ConnectionResult.Error(e, "Connection timed out", isTimeout = true)
            } catch (e: Exception) {
                ConnectionResult.Error(e, e.message ?: "Unknown error")
            }
        }

    // ── Initialization ────────────────────────────────────────────────────────

    suspend fun initializeDefaults() {
        DefaultAppConfigs.getDefaults().forEach { default ->
            if (getAppConfig(default.appId) == null) {
                networkConfigDao.insertAppConfig(default)
            }
        }
        if (getGlobalConfig() == null) saveGlobalConfig(GlobalNetworkConfig())
    }

    suspend fun resetToDefaults() {
        saveAllAppConfigs(DefaultAppConfigs.getDefaults())
        saveGlobalConfig(GlobalNetworkConfig())
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private suspend fun resolveAppConfig(appId: String): AppNetworkConfig? =
        getAppConfig(appId) ?: DefaultAppConfigs.getDefaults().find { it.appId == appId }

    private suspend fun isHostReachable(host: String, port: Int): Boolean {
        if (port == 0) return false
        return try {
            withContext(Dispatchers.IO) {
                Socket().use { it.connect(InetSocketAddress(host, port), 5000) }
                true
            }
        } catch (e: Exception) { false }
    }
}
