package com.Studio.Shadows.di

import android.content.Context
import com.Studio.Shadows.data.local.NetworkConfigDao
import com.Studio.Shadows.data.local.SecurityConfigDao
import com.Studio.Shadows.data.local.ShadowDatabase
import com.Studio.Shadows.security.EncryptedPreferenceManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt Dependency Injection Module for ShadowStudio.
 * TracerLogDao provider removed along with the Tracer Client.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideShadowDatabase(
        @ApplicationContext context: Context
    ): ShadowDatabase = ShadowDatabase.getDatabase(context)

    @Provides
    @Singleton
    fun provideSecurityConfigDao(database: ShadowDatabase): SecurityConfigDao =
        database.securityConfigDao()

    @Provides
    @Singleton
    fun provideNetworkConfigDao(database: ShadowDatabase): NetworkConfigDao =
        database.networkConfigDao()

    @Provides
    @Singleton
    fun provideEncryptedPreferenceManager(
        @ApplicationContext context: Context
    ): EncryptedPreferenceManager = EncryptedPreferenceManager(context)
}
