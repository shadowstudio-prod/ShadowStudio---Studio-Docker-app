package com.Studio.Shadows.workers

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.Studio.Shadows.R
import com.Studio.Shadows.data.managers.UpdateManager

/**
 * WorkManager worker that performs an automatic update check and install.
 *
 * Scheduled by [UpdateViewModel] as a [OneTimeWorkRequest] with an initial
 * delay calculated to the next occurrence of the user's chosen time.
 * When this worker runs it re-schedules itself for the following day so the
 * check recurs daily without requiring a PeriodicWorkRequest.
 *
 * Flow:
 *   1. Fetch update JSON from server.
 *   2. If a newer version exists, download the APK.
 *   3. Kick off a PackageInstaller session.
 *   4. Return Result.success() — the actual install outcome arrives via
 *      [InstallResultReceiver] / [PackageReplacedReceiver].
 *
 * If anything fails the worker returns Result.retry() so WorkManager applies
 * its back-off policy. After the retry window it returns Result.failure() so
 * the daily reschedule in UpdateViewModel still fires.
 */
class AutoUpdateWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val updateManager = UpdateManager(context)

    override suspend fun doWork(): Result {
        Log.i(TAG, "AutoUpdateWorker started")

        return try {
            val jsonUrl = context.getString(R.string.update_json_url)
            val info    = updateManager.fetchUpdateJson(jsonUrl)

            if (!updateManager.isUpdateRequired(info)) {
                Log.i(TAG, "Already up to date — nothing to do")
                return Result.success()
            }

            Log.i(TAG, "Update available: v${info.latestVersionName} — downloading…")
            val apkFile = updateManager.downloadApk(
                downloadUrl = info.updatePath,
                fileName    = UpdateManager.UPDATE_APK_NAME
            )

            Log.i(TAG, "Download complete (${apkFile.length()} bytes) — installing…")
            updateManager.installApk(apkFile)

            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "AutoUpdateWorker failed: ${e.message}", e)
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        }
    }

    companion object {
        private const val TAG = "AutoUpdateWorker"
        const val WORK_NAME   = "shadow_auto_update"
    }
}
